#我们项目的运行环境为Python 3.12.11
import pandas as pd    
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import find_peaks  #这是我们实现干涉峰检测的核心算法
from scipy.optimize import minimize  #在参数优化方面，我们选择最小二乘法来实现
import math

def load_and_preprocess(file_path, min_height=0.6, min_distance=50, prominence=0.3):
    """
    读取附件数据并进行干涉峰的动态检测
    """
    # 1. 读取Excel数据，同时将列名指定为波数("v")和反射率("R")
    df = pd.read_excel(file_path, header=None, names=["v", "R"])
    
    # 进行链式操作，采用字典推导推导式批量处理
    # 旨在一条龙实现“类型转换→去缺失→排序→重置索引”的整合，
    df = (
        df.assign(
            **{col: pd.to_numeric(df[col], errors="coerce") for col in ["v", "R"]}
        )
        .dropna(subset=["v", "R"])
        .sort_values("v")
        .reset_index(drop=True)
    )
    
    # 添加波长列，同时在使用公式时顺便进行了单位的转换
    df["λ"] = 1e4/ df["v"]      
    # 基于v[cm⁻¹] = 10⁴/λ[μm] 的光谱学定义，我们得到了波长转换公式：λ[μm] = 10⁴/v[cm⁻¹]
    
    # 2. 动态检测干涉峰
    # 设置参数可自动调整，直到找到合理数量的峰(预估5-30个为合理的可接受的范围)，随即终止
    #为了避免变量操作太过分散，我们采用封装存储策略，利用params字典以及adjust字典分别集中管理可调整参数和对应的调整因子
    params = {'min_h': min_height, 'min_d': min_distance}   
    adjust = {'under': (0.9, 0.8), 'over': (1.1, 1.2)}     
    peaks_idx, properties = [], {}
    
    for attempt in range(3):
        peaks_idx, properties = find_peaks(
            df["R"],
            height = params['min_h'],
            distance = params['min_d'],
            prominence = prominence,
            width = 20
        )
        
        # 检查峰数量是否合理，中断后可以方便调整参数
        cnt = len(peaks_idx)
        if 5 <= cnt <= 30:
            break
            
        # 用元组解包实现参数调整,减少嵌套
        h_factor, d_factor = adjust['under'] if cnt < 5 else adjust['over']
        params['min_h'] *= h_factor
        params['min_d'] *= d_factor
    else:
        print("警告：无法找到合理数量的干涉峰，使用当前检测结果")

    # loc可以做到批量提取峰数据，通过values.T转置后直接解包赋值，效率提升一大截
    peaks_data = df.loc[peaks_idx, ['v', 'R', 'λ']].values.T
    peaks_v, peaks_R, peaks_λ = peaks_data
    
    # 计算相邻峰波长差
    delta_λ = np.diff(peaks_λ)
    
    # 3. 可视化（增加了峰索引标注，更直观）
    plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "Arial Unicode MS"]   #绘图所需字体
    fig, axes = plt.subplots(2, 1, figsize=(15, 12))

    # 定义并集中管理子图所需要的参数
    plot_configs = [
        {"x_data": df["v"], "x_label": "波数 v (cm⁻¹)", "peak_x": peaks_v, "title_suffix": "波数"},
        {"x_data": df["λ"], "x_label": "波长 λ (μm)", "peak_x": peaks_λ, "title_suffix": "波长"}
    ]

    # 将绘图方式封装为函数，方便随时维护
    def plot_peak(ax, x_data, y_data, peak_x, peak_y, x_label, title):
        ax.plot(x_data, y_data, label="原始反射率")
        ax.scatter(peak_x, peak_y, color="red", label="检测到的干涉峰")
        # 用列表推导式简化循环，反正比for循环好
        [ax.text(x, y, f"峰{i+1}", fontsize=8, ha='right') 
         for i, (x, y) in enumerate(zip(peak_x, peak_y))]
        ax.set_xlabel(x_label)
        ax.set_ylabel("反射率 R (%)")
        ax.set_title(title)
        ax.legend()

    # 循环生成子图，共享固定的参数
    for ax, config in zip(axes, plot_configs):
        plot_peak(
            ax=ax,
            x_data=config["x_data"],
            y_data=df["R"],  
            peak_x=config["peak_x"],
            peak_y=peaks_R,  
            x_label=config["x_label"],
            title=f"{file_path} 峰值检测结果({config['title_suffix']})"
        )

    plt.tight_layout()
    plt.show()
    
    # 打印相邻峰波长差
    print("\n相邻干涉峰的波长差(μm):")
    for i in range(len(delta_λ)):
        print(f"峰{i+1}和峰{i+2}的波长差: {delta_λ[i]:.4f} μm (λ₁={peaks_λ[i]:.4f} μm, λ₂={peaks_λ[i+1]:.4f} μm)")
    
    return df, peaks_idx, peaks_v, peaks_R, peaks_λ, delta_λ

# 测试：处理附件1数据（已经优化了参数的管理方式，还是用字典封装）
attach1_params = {
    "file_path": "附件1.xlsx",
    "min_height": 0.8,
    "min_distance": 80,
    "prominence": 0.3
}

# 用元组解包接收返回值
attach1_df, attach1_peak_idx, attach1_peak_v, attach1_peak_R, attach1_peak_λ, attach1_delta_λ = load_and_preprocess(** attach1_params)

def optimize_parameters(peaks_λ, delta_λ, theta0=10):
    """优化计算a,b,d参数(采用多初始点优化，同时增强折射率约束)"""
    theta0_rad = math.radians(theta0)
    
    # 目标函数1：理论波长差公式
    def objective1(params): 
        a, b, d = params
        theta0_rad = math.radians(10)  # 按题目要求入射角固定为10°
        error = 0
        start_idx = 7     #动态区间防止边缘峰干扰增大误差
        end_idx = len(peaks_λ) - 2
        
        for i in range(start_idx, end_idx): 
            λ1, λ2 = peaks_λ[i], peaks_λ[i+1]  
            n1_sq = a - b * λ1**2  
            n2_sq = a - b * λ2**2  
            
            # 计算根号项(计算过程中加入判断确保根号下非负)
            term1 = math.sqrt(n1_sq - math.sin(theta0_rad)**2) if n1_sq > math.sin(theta0_rad)**2 else 0
            term2 = math.sqrt(n2_sq - math.sin(theta0_rad)**2) if n2_sq > math.sin(theta0_rad)**2 else 0
            
            if term1 == 0 or term2 == 0:
                return float('inf')  # 没有物理意义，进行惩罚
            
            # 核心公式：理论和实际的级次差都为1
            left = 2 * d * term2 / λ2
            right = 2 * d * term1 / λ1
            theory_diff = left - right    
            actual_diff = 1             
            error += (theory_diff - actual_diff) **2  # 对平方误差累计求和
        return error 
    
    # 目标函数2：增强对折射率约束(用指数级惩罚来确保物理合理性)
    def objective2(params):
        a, b, _ = params
        penalty = 0
        for λ in peaks_λ:
            n_sq = a - b * λ**2  
            if n_sq < 1.0**2:  # 检测折射率平方是否小于1(不符合实际就要约束)
                # 指数级惩罚：n越小，惩罚增长越快
                penalty += 100 * np.exp(10 * (1 - n_sq))  
            if n_sq < 0:  # 避免开方为负
                penalty += 1e15  # 更严重的惩罚
        return penalty
    
    # 多目标优化（增强约束权重）
    def multi_objective(params):
        return objective1(params) + 0.5 * objective2(params)  # 约束权重为0.5
    
    # 多初始点优化
    initial_guesses = [
        [3.1, 0.0016, 9.36],   
        [4.9, 0.0030, 10.23],
        [5.8, 0.0065, 11.81]
    ]
    
    bounds = [
        (1.5, 6.5),        # 要确保a - bλ² ≥ 1（λ最大时，a需足够大）
        (0.0005, 0.008),   # 降低b的上限可以减缓n²的下降速度
        (9.0, 12.0 )       # 厚度d的范围
    ]
    
    # 筛选最优结果
    best_result = None
    best_fun = float('inf')
    for guess in initial_guesses:
        res = minimize(
            multi_objective, 
            guess, 
            bounds=bounds, 
            method='SLSQP', 
            options={'maxiter': 5000, 'ftol': 1e-10, 'eps': 1e-6}
        )
        if res.success and res.fun < best_fun:
            best_fun = res.fun
            best_result = res
    
    if best_result is None:
        raise ValueError("所有初始点优化均失败，请检查参数范围或数据")
    
    optimal_params = {
        'a': best_result.x[0],
        'b': best_result.x[1],
        'd': best_result.x[2]
    }
    
    # 优化后验证折射率合理性 + 可视化折射率分布
    n_values = [math.sqrt(optimal_params['a'] - optimal_params['b'] * λ**2) for λ in peaks_λ]  
    print("\n折射率范围验证：")
    print(f"最小折射率: {min(n_values):.4f}")
    print(f"最大折射率: {max(n_values):.4f}")
    if any(n < 1.0 for n in n_values):
        print("警告：仍存在折射率<1的不合理值,需进一步调整！")
    else:
        print("折射率全部≥1,物理合理！")
    
    # 优化后验证折射率合理性
    n_values = [math.sqrt(optimal_params['a'] - optimal_params['b'] * λ**2) for λ in peaks_λ]  # 补全平方
    print("\n折射率范围验证：")
    print(f"最小折射率: {min(n_values):.4f}")
    print(f"最大折射率: {max(n_values):.4f}")
    if any(n < 1.0 for n in n_values):
        print("警告：存在折射率<1的不合理值,建议调整参数范围!")
    
    # 输出优化结果
    print("\n优化结果:")
    print(f"最优参数 a: {optimal_params['a']:.4f}")
    print(f"最优参数 b: {optimal_params['b']:.6f}")
    print(f"最优外延层厚度 d: {optimal_params['d']:.4f} μm")
    print(f"优化状态: {'成功' if best_result.success else '失败'}")
    print(f"目标函数值: {best_result.fun:.4e}")
    
    # 显示理论与实际波长差对比
    print("\n理论波长差 vs 实际波长差:")
    a, b, d = optimal_params['a'], optimal_params['b'], optimal_params['d']
    start_idx = 7
    end_idx = len(peaks_λ) - 2
    for i in range(start_idx, end_idx):
        λ1, λ2 = peaks_λ[i], peaks_λ[i+1]
        n1_sq = a - b * λ1**2 
        n2_sq = a - b * λ2**2  
        term1 = math.sqrt(n1_sq - math.sin(theta0_rad)**2)
        term2 = math.sqrt(n2_sq - math.sin(theta0_rad)** 2)
        theoretical_diff = (λ1 * λ2) / (2 * d * (term1 + term2))
        print(f"峰{i+1}-峰{i+2}: 理论{theoretical_diff:.4f} μm | 实际{delta_λ[i]:.4f} μm | 误差{abs(theoretical_diff-delta_λ[i]):.4f} μm")
    
    return best_result, optimal_params

def sensitivity_analysis(optimal_params, peaks_λ, delta_λ, theta0=10):
    """
    偏导数法灵敏度分析
    """
    a, b, d = optimal_params['a'], optimal_params['b'], optimal_params['d']
    theta0_rad = math.radians(theta0)
    h = 1e-6  # 微小的扰动步长
    
    print("\n=== 偏导数法参数灵敏度分析 ===")
    
    # 计算原始误差
    original_error = calculate_error(a, b, d, peaks_λ, delta_λ, theta0_rad)
    
    # 计算a的偏导数
    error_a_plus = calculate_error(a + h, b, d, peaks_λ, delta_λ, theta0_rad)
    partial_a = (error_a_plus - original_error) / h
    
    # 计算b的偏导数
    error_b_plus = calculate_error(a, b + h, d, peaks_λ, delta_λ, theta0_rad)
    partial_b = (error_b_plus - original_error) / h
    
    # 计算d的偏导数
    error_d_plus = calculate_error(a, b, d + h, peaks_λ, delta_λ, theta0_rad)
    partial_d = (error_d_plus - original_error) / h
    
    # 归一化处理
    norm_partial_a = abs(partial_a * a / original_error)
    norm_partial_b = abs(partial_b * b / original_error)
    norm_partial_d = abs(partial_d * d / original_error)
    
    print("\n参数灵敏度(偏导数):")
    print(f"参数a的偏导数: {partial_a:.4e}")
    print(f"参数b的偏导数: {partial_b:.4e}")
    print(f"参数d的偏导数: {partial_d:.4e}")
    
    print("\n归一化灵敏度(弹性系数):")
    print(f"参数a的弹性系数: {norm_partial_a:.4f}")
    print(f"参数b的弹性系数: {norm_partial_b:.4f}")
    print(f"参数d的弹性系数: {norm_partial_d:.4f}")
    
    # 绘制灵敏度柱状图
    params = ['a', 'b', 'd']
    sensitivities = [norm_partial_a, norm_partial_b, norm_partial_d]
    
    plt.figure(figsize=(8, 5))
    bars = plt.bar(params, sensitivities, color=['blue', 'green', 'red'])
    plt.title('归一化参数灵敏度(弹性系数)')
    plt.ylabel('灵敏度系数')
    plt.xlabel('参数')
    
    # 添加数值标签
    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2., height,
                 f'{height:.3f}',
                 ha='center', va='bottom')
    
    plt.grid(axis='y', linestyle='--', alpha=0.7)
    plt.tight_layout()
    plt.show()

def calculate_error(a, b, d, peaks_λ, delta_λ, theta0_rad):
    """计算给定参数下的总误差"""
    error = 0
    start_idx = 7
    end_idx = len(peaks_λ) - 2
    
    for i in range(start_idx, end_idx):
        λ1, λ2 = peaks_λ[i], peaks_λ[i+1]
        n1_sq = a - b * λ1**2
        n2_sq = a - b * λ2**2
        
        term1 = math.sqrt(n1_sq - math.sin(theta0_rad)**2) if n1_sq > math.sin(theta0_rad)**2 else 0
        term2 = math.sqrt(n2_sq - math.sin(theta0_rad)**2) if n2_sq > math.sin(theta0_rad)**2 else 0
        
        if term1 == 0 or term2 == 0:
            return float('inf')
            
        left = 2 * d * term2 / λ2
        right = 2 * d * term1 / λ1
        theory_diff = left - right
        error += (theory_diff - 1) ** 2
        
    return error

# 执行优化和灵敏度分析
if __name__ == "__main__":
    result, params = optimize_parameters(attach1_peak_λ, attach1_delta_λ)
    
    sensitivity_analysis(params, attach1_peak_λ, attach1_delta_λ)