import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import find_peaks
from scipy.optimize import minimize
import math

def load_and_preprocess(file_path, min_height=0.6, min_distance=50, prominence=0.3):
    """
    读取附件数据并检测干涉峰（动态调整参数）
    """
    # 1. 读取Excel数据
    df = pd.read_excel(file_path, header=None, names=["v", "R"])
    
    # 处理数据类型问题
    df["v"] = pd.to_numeric(df["v"], errors="coerce")
    df["R"] = pd.to_numeric(df["R"], errors="coerce")
    df = df.dropna(subset=["v", "R"])
    
    df = df.sort_values("v").reset_index(drop=True)
    
    # 添加波长列
    df["λ"] = 10**4 / df["v"]
    
    # 2. 动态检测干涉峰
    # 自动调整参数直到找到合理数量的峰(5-30个)
    for attempt in range(3):
        peaks_idx, properties = find_peaks(
            df["R"],
            height=min_height,
            distance=min_distance,
            prominence=prominence,
            width=20
        )
        
        # 检查峰数量是否合理
        if 5 <= len(peaks_idx) <= 30:
            break
            
        # 动态调整参数
        if len(peaks_idx) < 5:
            min_height *= 0.9
            min_distance *= 0.8
        else:
            min_height *= 1.1
            min_distance *= 1.2
    else:
        print("警告：无法找到合理数量的干涉峰，使用当前检测结果")
    peaks_v = df.iloc[peaks_idx]["v"].values
    peaks_R = df.iloc[peaks_idx]["R"].values
    peaks_λ = df.iloc[peaks_idx]["λ"].values
    
    # 计算相邻峰波长差
    delta_λ = np.diff(peaks_λ)
    
    # 3. 可视化（增加峰索引标注）
    plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "Arial Unicode MS"]
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(15, 12))

    # 子图1：波数-反射率
    ax1.plot(df["v"], df["R"], label="原始反射率")
    ax1.scatter(peaks_v, peaks_R, color="red", label="检测到的干涉峰")
    for i, (x, y) in enumerate(zip(peaks_v, peaks_R)):
        ax1.text(x, y, f"峰{i+1}", fontsize=8, ha='right')
    ax1.set_xlabel("波数 v (cm⁻¹)")
    ax1.set_ylabel("反射率 R (%)")
    ax1.set_title(f"{file_path} 峰值检测结果(波数)")
    ax1.legend()

    # 子图2：波长-反射率
    ax2.plot(df["λ"], df["R"], label="原始反射率")
    ax2.scatter(peaks_λ, peaks_R, color="red", label="检测到的干涉峰")
    for i, (x, y) in enumerate(zip(peaks_λ, peaks_R)):
        ax2.text(x, y, f"峰{i+1}", fontsize=8, ha='right')
    ax2.set_xlabel("波长 λ (μm)")
    ax2.set_ylabel("反射率 R (%)")
    ax2.set_title(f"{file_path} 峰值检测结果(波长)")
    ax2.legend()

    plt.tight_layout()
    plt.show()
    
    # 打印相邻峰波长差
    print("\n相邻干涉峰的波长差(μm):")
    for i in range(len(delta_λ)):
        print(f"峰{i+1}和峰{i+2}的波长差: {delta_λ[i]:.4f} μm (λ₁={peaks_λ[i]:.4f} μm, λ₂={peaks_λ[i+1]:.4f} μm)")
    
    return df, peaks_idx, peaks_v, peaks_R, peaks_λ, delta_λ

# 测试：处理附件1（优化峰值检测参数）
df1, peaks_idx1, peaks_v1, peaks_R1, peaks_λ1, delta_λ1 = load_and_preprocess(
    "附件1.xlsx", 
    min_height=0.8, 
    min_distance=80, 
    prominence=0.3
)

def optimize_parameters(peaks_λ, delta_λ, theta0=10):
    """
    优化计算a,b,d参数(多初始点优化 + 增强折射率约束)
    """
    theta0_rad = math.radians(theta0)
    
    # 目标函数1：理论波长差公式（动态区间）
    def objective1(params): 
        a, b, d = params
        theta0_rad = math.radians(10)  # 假设入射角固定为10°
        error = 0
        start_idx = 7
        end_idx = len(peaks_λ) - 2
        
        for i in range(start_idx, end_idx): 
            λ1, λ2 = peaks_λ[i], peaks_λ[i+1]  
            n1_sq = a - b * λ1**2  
            n2_sq = a - b * λ2**2  
            
            # 计算根号项（确保非负）
            term1 = math.sqrt(n1_sq - math.sin(theta0_rad)**2) if n1_sq > math.sin(theta0_rad)**2 else 0
            term2 = math.sqrt(n2_sq - math.sin(theta0_rad)**2) if n2_sq > math.sin(theta0_rad)**2 else 0
            
            if term1 == 0 or term2 == 0:
                return float('inf')  # 无物理意义，惩罚
            
            # 核心公式：级次差为1
            left = 2 * d * term2 / λ2
            right = 2 * d * term1 / λ1
            theory_diff = left - right  # 理论上应为1
            actual_diff = 1  # 实际级次差为1
            error += (theory_diff - actual_diff) **2  # 平方误差累计
        return error 
    
    # 目标函数2：增强折射率约束（指数级惩罚 + 硬约束）
    def objective2(params):
        a, b, _ = params
        penalty = 0
        for λ in peaks_λ:
            n_sq = a - b * λ**2  
            if n_sq < 1.0**2:  # 检测折射率平方是否小于1
                # 指数级惩罚：n越小，惩罚增长越快
                penalty += 100 * np.exp(10 * (1 - n_sq))  
            if n_sq < 0:  # 避免开方负数
                penalty += 1e15  # 更严重的惩罚
        return penalty
    
    # 多目标优化（增强约束权重）
    def multi_objective(params):
        return objective1(params) + 0.5 * objective2(params)  # 提高约束权重（从1.5→5.0）
    
    # 多初始点优化
    initial_guesses = [
        [3.2, 0.0016, 5.0],   
        [4.8, 0.0030, 12.0],
        [6.5, 0.0065, 18.0]
    ]
    
    bounds = [
        (2, 7),    # 提高a的下限，确保a - bλ² ≥ 1（λ最大时，a需足够大）
        (0.0005, 0.008), # 降低b的上限，减缓n²的下降速度
        (1.0, 20 )    # d：调整厚度范围
    ]
    
    # 筛选最优结果
    best_result = None
    best_fun = float('inf')
    for guess in initial_guesses:
        res = minimize(
            multi_objective, 
            guess, 
            bounds=bounds, 
            method='SLSQP', 
            options={'maxiter': 5000, 'ftol': 1e-10, 'eps': 1e-6}
        )
        if res.success and res.fun < best_fun:
            best_fun = res.fun
            best_result = res
    
    if best_result is None:
        raise ValueError("所有初始点优化均失败，请检查参数范围或数据")
    
    optimal_params = {
        'a': best_result.x[0],
        'b': best_result.x[1],
        'd': best_result.x[2]
    }
    
    # 优化后验证折射率合理性 + 可视化折射率分布
    n_values = [math.sqrt(optimal_params['a'] - optimal_params['b'] * λ**2) for λ in peaks_λ]  
    print("\n折射率范围验证：")
    print(f"最小折射率: {min(n_values):.4f}")
    print(f"最大折射率: {max(n_values):.4f}")
    if any(n < 1.0 for n in n_values):
        print("警告：仍存在折射率<1的不合理值,需进一步调整！")
    else:
        print("折射率全部≥1,物理合理！")
    
    # 优化后验证折射率合理性
    n_values = [math.sqrt(optimal_params['a'] - optimal_params['b'] * λ**2) for λ in peaks_λ]  # 补全平方
    print("\n折射率范围验证：")
    print(f"最小折射率: {min(n_values):.4f}")
    print(f"最大折射率: {max(n_values):.4f}")
    if any(n < 1.0 for n in n_values):
        print("警告：存在折射率<1的不合理值,建议调整参数范围!")
    
    # 输出优化结果
    print("\n优化结果:")
    print(f"最优参数 a: {optimal_params['a']:.4f}")
    print(f"最优参数 b: {optimal_params['b']:.6f}")
    print(f"最优外延层厚度 d: {optimal_params['d']:.4f} μm")
    print(f"优化状态: {'成功' if best_result.success else '失败'}")
    print(f"目标函数值: {best_result.fun:.4e}")
    
    # 显示理论与实际波长差对比
    print("\n理论波长差 vs 实际波长差:")
    a, b, d = optimal_params['a'], optimal_params['b'], optimal_params['d']
    start_idx = 7
    end_idx = len(peaks_λ) - 2
    for i in range(start_idx, end_idx):
        λ1, λ2 = peaks_λ[i], peaks_λ[i+1]
        n1_sq = a - b * λ1**2 
        n2_sq = a - b * λ2**2  
        term1 = math.sqrt(n1_sq - math.sin(theta0_rad)**2)
        term2 = math.sqrt(n2_sq - math.sin(theta0_rad)** 2)
        theoretical_diff = (λ1 * λ2) / (2 * d * (term1 + term2))
        print(f"峰{i+1}-峰{i+2}: 理论{theoretical_diff:.4f} μm | 实际{delta_λ[i]:.4f} μm | 误差{abs(theoretical_diff-delta_λ[i]):.4f} μm")
    
    return best_result, optimal_params

def sensitivity_analysis(optimal_params, peaks_λ, delta_λ, theta0=10, n_samples=1000):
    """
    使用Sobol指数法进行全局灵敏度分析(矩阵实现)
    """
    try:
        from SALib.analyze import sobol
        from SALib.sample import saltelli
        
        a, b, d = optimal_params['a'], optimal_params['b'], optimal_params['d']
        theta0_rad = math.radians(theta0)
        
        # 定义问题(矩阵形式)
        problem = {
            'num_vars': 3,
            'names': ['a', 'b', 'd'],
            'bounds': np.array([
                [a * 0.8, a * 1.2],  # a的范围
                [b * 0.5, b * 1.5],  # b的范围
                [d * 0.8, d * 1.2]   # d的范围
            ])
        }
        
        # 生成样本点矩阵(Saltelli采样)
        param_values = saltelli.sample(problem, n_samples, calc_second_order=True)
        
        # 矩阵化计算模型输出
        Y = np.array([calculate_error(*X, peaks_λ, delta_λ, theta0_rad) 
                     for X in param_values])
        
        # 计算Sobol指数矩阵
        Si = sobol.analyze(problem, Y, calc_second_order=True, print_to_console=False)
        
        # 可视化结果
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
        
        # 一阶指数
        ax1.bar(problem['names'], Si['S1'], color='skyblue')
        ax1.set_title('一阶Sobol指数')
        ax1.set_ylabel('灵敏度指数')
        ax1.set_ylim(0, 1)
        
        # 总阶指数
        ax2.bar(problem['names'], Si['ST'], color='lightgreen')
        ax2.set_title('总阶Sobol指数')
        ax2.set_ylabel('灵敏度指数')
        ax2.set_ylim(0, 1)
        
        plt.tight_layout()
        plt.show()
        
        # 打印详细结果
        print("\n=== Sobol灵敏度分析结果 ===")
        print(f"一阶指数(S1): {Si['S1']}")
        print(f"总阶指数(ST): {Si['ST']}")
        if Si['S2'] is not None:
            print("\n二阶交互作用矩阵:")
            print(Si['S2'])
        
        return Si
    except ImportError:
        print("未安装SALib库，请先运行: pip install SALib")
        return None

def calculate_error(a, b, d, peaks_λ, delta_λ, theta0_rad):
    """
    计算给定参数下的总误差
    """
    error = 0
    start_idx = 7
    end_idx = len(peaks_λ) - 2
    
    for i in range(start_idx, end_idx):
        λ1, λ2 = peaks_λ[i], peaks_λ[i+1]
        n1_sq = a - b * λ1**2
        n2_sq = a - b * λ2**2
        
        term1 = math.sqrt(n1_sq - math.sin(theta0_rad)**2) if n1_sq > math.sin(theta0_rad)**2 else 0
        term2 = math.sqrt(n2_sq - math.sin(theta0_rad)**2) if n2_sq > math.sin(theta0_rad)**2 else 0
        
        if term1 == 0 or term2 == 0:
            return float('inf')
            
        left = 2 * d * term2 / λ2
        right = 2 * d * term1 / λ1
        theory_diff = left - right
        error += (theory_diff - 1) ** 2
        
    return error

# 执行优化和灵敏度分析
if __name__ == "__main__":
    result, params = optimize_parameters(peaks_λ1, delta_λ1)
    # 使用Sobol方法进行灵敏度分析
    sensitivity_analysis(params, peaks_λ1, delta_λ1, n_samples=1000)