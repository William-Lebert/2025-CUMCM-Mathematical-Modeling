import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import find_peaks
from scipy.optimize import curve_fit
import math

# 4H-SiC折射率模型(全域拟合结果)
def refractive_index(λ):
    """根据波长(μm)计算4H-SiC折射率"""
    epsilon_inf = 6.447  # 高频介电常数
    ω_LO = 968.8  # 纵光学声子频率
    ω_TO = 802.8  # 横光学声子频率
    Γ = 1.166  # 阻尼系数
    ω_P = 1836  # 等离子体频率
    γ = 9000  # 等离子体阻尼系数
    
    # 将波长转换为波数
    v = 10**4 / λ
    
    # 介电函数模型
    ε = epsilon_inf * (1 + (ω_LO**2 - ω_TO**2)/(ω_TO**2 - v**2 - 1j*Γ*v) 
               - ω_P**2/(v*(v + 1j*γ)))
    
    return np.sqrt(ε.real)  # 取实部作为折射率

# 附加相移计算
def additional_phase_shift(λ, n_epi=2.5, n_sub=2.6):
    """计算外延层-衬底界面的附加相移"""
    return 0.033  

def load_and_preprocess(file_path, min_height=0.6, min_distance=50, prominence=0.3):
    """
    读取附件数据并检测干涉峰（动态调整参数）
    """
    # 1. 读取Excel数据
    df = pd.read_excel(file_path, header=None, names=["v", "R"])
    
    # 处理数据类型问题
    df["v"] = pd.to_numeric(df["v"], errors="coerce")
    df["R"] = pd.to_numeric(df["R"], errors="coerce")
    df = df.dropna(subset=["v", "R"])
    
    df = df.sort_values("v").reset_index(drop=True)
    
    # 添加波长列
    df["λ"] = 10**4 / df["v"]
    
    # 2. 动态检测干涉峰
    # 自动调整参数直到找到合理数量的峰(5-30个)
    for attempt in range(3):
        peaks_idx, properties = find_peaks(
            df["R"],
            height=min_height,
            distance=min_distance,
            prominence=prominence,
            width=20
        )
        
        # 检查峰数量是否合理
        if 5 <= len(peaks_idx) <= 30:
            break
            
        # 动态调整参数
        if len(peaks_idx) < 5:
            min_height *= 0.9
            min_distance *= 0.8
        else:
            min_height *= 1.1
            min_distance *= 1.2
    else:
        print("警告：无法找到合理数量的干涉峰，使用当前检测结果")
    peaks_v = df.iloc[peaks_idx]["v"].values
    peaks_R = df.iloc[peaks_idx]["R"].values
    peaks_λ = df.iloc[peaks_idx]["λ"].values
    
    # 计算相邻峰波长差
    delta_λ = np.diff(peaks_λ)

    plt.tight_layout()
    plt.show()
    
    # 打印相邻峰波长差
    print("\n相邻干涉峰的波长差(μm):")
    for i in range(len(delta_λ)):
        print(f"峰{i+1}和峰{i+2}的波长差: {delta_λ[i]:.4f} μm (λ₁={peaks_λ[i]:.4f} μm, λ₂={peaks_λ[i+1]:.4f} μm)")
    
    return df, peaks_idx, peaks_v, peaks_R, peaks_λ, delta_λ

# 测试：处理附件1（优化峰值检测参数）
df1, peaks_idx1, peaks_v1, peaks_R1, peaks_λ1, delta_λ1 = load_and_preprocess(
    "附件1.xlsx", 
    min_height=0.8, 
    min_distance=80, 
    prominence=0.3
)

def linear_fit_thickness(peaks_λ, peaks_v, peaks_R, theta0=10):
    """
    线性拟合算法计算厚度
    参数:
        peaks_λ: 检测到的干涉峰波长数组(μm)
        peaks_v: 检测到的干涉峰波数数组(cm⁻¹)
        peaks_R: 检测到的干涉峰反射率数组(%)
        theta0: 入射角(度), 默认为10°
    返回:
        h: 拟合得到的外延层厚度(μm)
        p0: 参考点级数
        results_df: 结果数据表格
    """
    from scipy.optimize import curve_fit
    import math
    import pandas as pd
    
    # 转换为弧度
    theta0_rad = math.radians(theta0)
    
    # 选择中间区域的反射率最高点作为参考点
    mid_idx = len(peaks_R) // 2
    window = 3  # 查看中间±3个点
    start = max(0, mid_idx - window)
    end = min(len(peaks_R), mid_idx + window)
    ref_idx = start + np.argmax(peaks_R[start:end])
    v_ref = peaks_v[ref_idx]
    λ_ref = peaks_λ[ref_idx]
    
    # 计算级数差函数
    def delta_p_func(v, p0, h):
        # 4H-SiC折射率模型
        # 使用优化算法得到的折射率参数
        a = 5.4523  # 从优化结果获取
        b = 0.007129  # 从优化结果获取
        n = np.sqrt(a - b * (10**4/v)**2) 
        
        # 计算折射角
        sin_theta = np.sin(theta0_rad)
        cos_theta = np.sqrt(1 - (sin_theta/n)**2)
        
        # 线性拟合公式
        return 2 * n * h * (v/10000) * cos_theta + p0 - 0.5
    
    # 准备拟合数据(使用所有峰)
    v_data = np.delete(peaks_v, ref_idx)  # 移除参考点
    delta_p_data = 0.5 * np.arange(1, len(v_data)+1)  # 级数差为0.5, 1.0, 1.5...
    
    # 第一步拟合(同时拟合p0和h) - 使用与优化方法一致的参数范围
    popt, pcov = curve_fit(
        delta_p_func,
        v_data,
        delta_p_data,
        bounds=([1, 7.0], [10, 12.0]),  # p0范围[1,10], h范围[7.0,12.0]μm
        p0=[5, 9.5]  # 初始猜测更接近优化结果
    )
    p0_est, h_est = popt
    
    # 第二步拟合(修正p0为整数或半整数)
    # 根据参考点是波峰(整数)还是波谷(半整数)决定
    is_valley = peaks_R[ref_idx] < np.mean(peaks_R)  # 判断是否为波谷
    if is_valley:
        p0_rounded = round(p0_est * 2) / 2  # 取最近的半整数
    else:
        p0_rounded = round(p0_est)  # 取最近的整数
    
    # 固定p0后重新拟合h
    def delta_p_func_fixed_p0(v, h):
        return delta_p_func(v, p0_rounded, h)
    
    popt_fixed, pcov_fixed = curve_fit(
        delta_p_func_fixed_p0,
        v_data,
        delta_p_data,
        bounds=(1.0, 20.0),  # 扩大h范围[1.0,20.0]μm
        p0=h_est
    )
    h_final = popt_fixed[0]
    h_error = np.sqrt(np.diag(pcov_fixed))[0]  # 厚度误差估计
    
    # 生成结果表格
    results = {
        "第一步": {
            "h(μm)": f"{h_est:.2f} ({popt[1]-np.sqrt(pcov[1,1]):.2f}, {popt[1]+np.sqrt(pcov[1,1]):.2f})",
            "P0": f"{p0_est:.3f} ({popt[0]-np.sqrt(pcov[0,0]):.3f}, {popt[0]+np.sqrt(pcov[0,0]):.3f})"
        },
        "第二步": {
            "h(μm)": f"{h_final:.2f} ({h_final-h_error:.2f}, {h_final+h_error:.2f})",
            "P0": f"{p0_rounded:.1f}"
        }
    }
    results_df = pd.DataFrame(results)
    
    # 准备拟合数据
    v_data = peaks_v[1:]  # 使用除参考点外的所有峰
    delta_p_data = 0.5 * np.arange(1, len(v_data)+1)  # 级数差为0.5, 1.0, 1.5...
    
    # 第一步拟合
    popt, pcov = curve_fit(
        delta_p_func,
        v_data,
        delta_p_data,
        bounds=([1, 3.0], [10, 6.0]),  # p0范围[1,10], h范围[3.0,6.0]μm
        p0=[5, 4.5]  # 初始猜测
    )
    
    p0_est, h_est = popt
    
    # 第二步拟合(修正p0为半整数)
    p0_rounded = round(p0_est * 2) / 2  # 取最近的半整数
    
    # 固定p0后重新拟合h
    def delta_p_func_fixed_p0(v, h):
        return delta_p_func(v, p0_rounded, h)
    
    popt_fixed, pcov_fixed = curve_fit(
        delta_p_func_fixed_p0,
        v_data,
        delta_p_data,
        bounds=(1, 20),  # h范围[1,20]μm
        p0=h_est
    )
    
    h_final = popt_fixed[0]
    
    # 绘制拟合结果
    plt.figure(figsize=(12, 8))
    v_plot = np.linspace(min(v_data), max(v_data), 100)
    
    # 实验数据点
    plt.plot(v_data, delta_p_data, 'bo', markersize=8, label='实验数据')
    
    # 拟合曲线
    plt.plot(v_plot, delta_p_func_fixed_p0(v_plot, h_final), 
             'r-', linewidth=2, label='拟合曲线')
    
    # 显示函数表达式
    a = 5.4523
    b = 0.007129
    theta0_rad = math.radians(theta0)
    
    # 转换为y = ax + b形式
    slope = 2 * h_final * (1/10000)  # 斜率a
    intercept = p0_rounded - 0.5     # 截距b
    
    # 原始函数表达式
    func_text = (f"ΔP = 2 * n(v) * {h_final:.2f} * (v/10000) * cosθ + {p0_rounded:.1f} - 0.5\n"
                f"其中: n(v) = √({a} - {b}*(10⁴/v)²)\n"
                f"θ = arcsin(sin({theta0}°)/n(v))")
    
    # 线性形式表达式
    linear_text = f"线性形式: y = {slope:.6f} * x + {intercept:.2f}"
    
    plt.text(0.02, 0.98, func_text + "\n\n" + linear_text, 
             transform=plt.gca().transAxes,
             fontsize=12, verticalalignment='top',
             bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
    
    # 打印线性形式
    print("\n线性拟合方程(y = ax + b):")
    print(linear_text)
    
    # 图表格式设置
    plt.xlabel('波数 (cm⁻¹)', fontsize=14)
    plt.ylabel('级数差 ΔP', fontsize=14)
    plt.title('线性拟合结果', fontsize=16)
    plt.legend(fontsize=12, loc='upper right')
    plt.grid(True, linestyle='--', alpha=0.6)
    
    # 设置坐标轴范围
    x_pad = (max(v_data) - min(v_data)) * 0.1
    y_pad = (max(delta_p_data) - min(delta_p_data)) * 0.2
    plt.xlim(1877, 3820) 
    plt.ylim(min(delta_p_data)-y_pad, max(delta_p_data)+y_pad)
    
    # 设置刻度字体大小
    plt.xticks(fontsize=12)
    plt.yticks(fontsize=12)
    
    plt.tight_layout()
    plt.show()
    
    return h_final, p0_rounded, results_df

# 执行计算（传入检测到的峰参数）
if __name__ == "__main__":
    # 使用线性拟合方法计算厚度
    h_linear, p0, results_df = linear_fit_thickness(peaks_λ1, peaks_v1, peaks_R1)
    
    # 打印线性拟合结果
    print("\n线性拟合厚度计算结果:")
    print(f"参考点级数 P0: {p0}")
    print(f"外延层厚度 h: {h_linear:.4f} μm")