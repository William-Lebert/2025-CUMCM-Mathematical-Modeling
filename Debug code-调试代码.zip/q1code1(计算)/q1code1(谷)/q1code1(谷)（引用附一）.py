import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import find_peaks, savgol_filter
import math

def load_and_preprocess(file_path, min_height=0.1, min_distance=20, prominence=0.1, min_wavelength_diff=0.2):
    """
    读取附件数据并检测干涉谷（增加谷点筛选功能）
    min_wavelength_diff: 相邻谷点的最小波长差阈值(μm)，用于筛选过近的谷点
    """
    # 1. 读取Excel数据
    df = pd.read_excel(file_path, header=None, names=["v", "R"])
    
    # 处理数据类型问题
    df["v"] = pd.to_numeric(df["v"], errors="coerce")
    df["R"] = pd.to_numeric(df["R"], errors="coerce")
    df = df.dropna(subset=["v", "R"])
    
    df = df.sort_values("v").reset_index(drop=True)
    
    # 添加波长列
    df["λ"] = 10**4 / df["v"]
    print(f"数据范围 - 波数: {df['v'].min():.2f}~{df['v'].max():.2f} cm⁻¹，波长: {df['λ'].min():.4f}~{df['λ'].max():.4f} μm")
    
    # 2. 数据平滑处理
    window_length = min(51, len(df) // 5)
    if window_length % 2 == 0:
        window_length += 1
    df["R_smoothed"] = savgol_filter(df["R"], window_length=window_length, polyorder=3)
    
    # 3. 波谷检测逻辑
    valleys_idx = []
    properties = {}
    
    for attempt in range(15):
        current_distance = max(1, min_distance)
        
        valleys_idx, properties = find_peaks(
            -df["R_smoothed"],
            height=-min_height,
            distance=current_distance,
            prominence=prominence,
            width=3,
            rel_height=0.8
        )
        
        print(f"尝试 {attempt+1}: 检测到{len(valleys_idx)}个波谷 | 参数: height={min_height:.3f}, distance={current_distance:.1f}, prominence={prominence:.3f}")
        
        if 3 <= len(valleys_idx) <= 50:
            break
            
        if len(valleys_idx) < 3:
            min_height *= 0.4
            min_distance *= 0.5
            prominence *= 0.4
        else:
            min_height *= 1.2
            min_distance *= 1.2
            prominence *= 1.2
    else:
        print("警告：无法找到合理数量的干涉谷，使用当前检测结果")
    
    # 处理未检测到波谷的极端情况
    if len(valleys_idx) == 0:
        print("严重警告：未检测到任何波谷，请检查数据或手动标记波谷")
        sorted_R = df.sort_values("R")
        valleys_idx = sorted_R.index[:5].tolist()
        valleys_idx.sort()
    
    # 关键优化：筛选过近的谷点（保留前面噪声区域，主要过滤后期过近点）
    if len(valleys_idx) > 1:
        # 按波长从大到小排序（保持原始顺序，因为波数增大波长减小）
        filtered_idx = [valleys_idx[0]]  # 保留第一个谷点
        # 遍历后续谷点，筛选出与前一个保留点波长差大于阈值的点
        for idx in valleys_idx[1:]:
            current_λ = df.iloc[idx]['λ']
            last_λ = df.iloc[filtered_idx[-1]]['λ']
            # 计算波长差的绝对值（处理波长递减的情况）
            if abs(current_λ - last_λ) > min_wavelength_diff:
                filtered_idx.append(idx)
        # 更新谷点数据
        valleys_idx = filtered_idx
        print(f"筛选后保留{len(valleys_idx)}个谷点（最小波长差阈值：{min_wavelength_diff}μm）")
    
    valleys_v = df.iloc[valleys_idx]["v"].values
    valleys_R = df.iloc[valleys_idx]["R"].values
    valleys_λ = df.iloc[valleys_idx]["λ"].values
    
    # 计算相邻谷波长差
    delta_λ = np.diff(valleys_λ)
    
    # 3. 可视化
    plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "Arial"]
    plt.rcParams['axes.unicode_minus'] = False
    fig, ax1 = plt.subplots(figsize=(20, 10))

    ax1.plot(df["v"], df["R"], label="原始反射率", linewidth=2, alpha=0.7)
    ax1.plot(df["v"], df["R_smoothed"], label="平滑反射率", linewidth=3, linestyle='--', color='orange')
    ax1.scatter(valleys_v, valleys_R, color="red", label="检测到的干涉谷", s=50, zorder=5)
    
    for i, (x, y) in enumerate(zip(valleys_v, valleys_R)):
        ax1.text(x, y, f"谷{i+1}", fontsize=20, ha='right')
    
    ax1.set_xlabel("波数 v (cm⁻¹)", fontsize=28)
    ax1.set_ylabel("反射率 R (%)", fontsize=28)
    ax1.set_title(f"{file_path} 谷值检测结果(波数)", fontsize=28)
    ax1.legend(fontsize=20)
    ax1.tick_params(axis='both', which='major', labelsize=20)

    plt.tight_layout()
    plt.show()
    
    # 打印相邻谷波长差
    print("\n相邻干涉谷的波长差(μm):")
    for i in range(len(delta_λ)):
        print(f"谷{i+1}和谷{i+2}的波长差: {delta_λ[i]:.4f} μm (λ₁={valleys_λ[i]:.4f} μm, λ₂={valleys_λ[i+1]:.4f} μm)")
    
    return df, valleys_idx, valleys_v, valleys_R, valleys_λ, delta_λ

def calculate_parameters(valleys_λ, delta_λ):
    """计算a,b,d参数(增加异常处理)"""
    theta0_rad = math.radians(10)
    a_list = []
    b_list = []
    d_list = []
    
    if len(delta_λ) < 1:
        print("警告：没有足够的波谷数据计算参数")
        return {'a': [], 'b': [], 'd': [], 'avg_a': 0, 'avg_b': 0, 'avg_d': 0}
    
    # 计算每对相邻谷的参数（放宽阈值，允许更小的波长差）
    for i in range(len(delta_λ)):
        λ1, λ2 = valleys_λ[i], valleys_λ[i+1]
        Δλ = delta_λ[i]
        
        # 降低最小波长差阈值，避免过多筛选
        if abs(Δλ) < 0.05:  # 从1e-6放宽到0.05μm
            print(f"警告：第{i+1}对波谷波长差过小({Δλ:.4f}μm)，跳过计算")
            continue
            
        d = (λ1 * λ2) / (2 * Δλ * math.sqrt(1 - math.sin(theta0_rad)**2))
        d_list.append(d)
    
    if not d_list:
        print("警告：无法计算d值")
        return {'a': [], 'b': [], 'd': [], 'avg_a': 0, 'avg_b': 0, 'avg_d': 0}
    
    # 计算n值和λ平方
    n_values = []
    λ_squared = []
    for i in range(min(len(valleys_λ)-1, len(d_list))):
        λ = valleys_λ[i]
        Δλ = delta_λ[i]
        if abs(Δλ) < 0.05:
            continue
        n = λ / (2 * d_list[i] * math.sqrt(1 - math.sin(theta0_rad)**2))
        n_values.append(n**2)
        λ_squared.append(λ**2)
    
    if len(n_values) < 2:
        print("警告：数据点不足，无法计算a和b")
        a, b = 0, 0
    else:
        A = np.vstack([np.ones(len(λ_squared)), -np.array(λ_squared)]).T
        b, a = np.linalg.lstsq(A, n_values, rcond=None)[0]
    
    a_list = [a] * len(d_list)
    b_list = [b] * len(d_list)
    avg_a = a
    avg_b = b
    avg_d = np.mean(d_list)
    
    print("\n计算得到的参数:")
    print(f"a值: {avg_a:.4f}")
    print(f"b值: {avg_b:.6f}")
    print(f"d值列表: {[f'{x:.4f}' for x in d_list]}")
    print("\n平均值:")
    print(f"平均a值: {avg_a:.4f}")
    print(f"平均b值: {avg_b:.6f}")
    print(f"平均d值: {avg_d:.4f} μm")
    
    return {
        'a': a_list,
        'b': b_list,
        'd': d_list,
        'avg_a': avg_a,
        'avg_b': avg_b,
        'avg_d': avg_d
    }

def calculate_new_reflectivity(df, params):
    """计算新反射率(增加异常处理)"""
    theta0_rad = math.radians(10)
    avg_a = params['avg_a']
    avg_b = params['avg_b']
    avg_d = params['avg_d']
    
    if avg_a <= 0 or avg_d <= 0:
        df['R_new'] = np.nan
        print("警告：参数无效，无法计算新反射率")
        return df
    
    df['n_squared'] = avg_a - avg_b * (df['λ']**2)
    df['n_squared'] = df['n_squared'].clip(lower=1e-6)
    df['n'] = np.sqrt(df['n_squared'])
    
    df['R_new'] = 4 * (df['n'] - 1)**2 / (df['n'] + 1)** 2
    
    return df

# 测试：处理附件1
if __name__ == "__main__":
    df1, valleys_idx1, valleys_v1, valleys_R1, valleys_λ1, delta_λ1 = load_and_preprocess(
        "附件1.xlsx", 
        min_height=0.5,    
        min_distance=50,   
        prominence=0.2,
        min_wavelength_diff=0.2  # 可调整的最小波长差阈值，默认0.2μm
    )
    
    params = calculate_parameters(valleys_λ1, delta_λ1)
    
    df1 = calculate_new_reflectivity(df1, params)
    
    plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC", "Arial"]
    plt.rcParams['axes.unicode_minus'] = False
    fig, ax = plt.subplots(figsize=(20, 10))
    
    ax.plot(df1["v"], df1["R"], label="原始反射率", linewidth=4)
    ax.plot(df1["v"], df1["R_new"], label="计算反射率", linewidth=4, linestyle='--')
    ax.scatter(valleys_v1, valleys_R1, color="red", label="检测到的干涉谷", s=50)
    for i, (x, y) in enumerate(zip(valleys_v1, valleys_R1)):
        ax.text(x, y, f"谷{i+1}", fontsize=20, ha='right')
    
    ax.set_xlabel("波数 v (cm⁻¹)", fontsize=28)
    ax.set_ylabel("反射率 R (%)", fontsize=28)
    ax.set_title("原始反射率与计算反射率比较", fontsize=28)
    ax.legend(fontsize=20)
    ax.tick_params(axis='both', which='major', labelsize=20)
    
    plt.tight_layout()
    plt.show()