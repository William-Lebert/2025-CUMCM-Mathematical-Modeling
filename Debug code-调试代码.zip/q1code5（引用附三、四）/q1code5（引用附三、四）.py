import numpy as np
import matplotlib.pyplot as plt
import math
from scipy.optimize import curve_fit

def refractive_index(wavelength, material):
    """
    计算材料的折射率
    wavelength: 波长(μm)
    material: 材料名称("硅"或"碳化硅")
    """
    if material == "硅":
        # 硅的折射率模型
        return 3.48 - 0.01j + (0.1 / wavelength)
    elif material == "碳化硅":
        # 碳化硅的折射率模型 
        return 2.65 - 0.005j + (0.05 / wavelength)
    else:
        raise ValueError("不支持的材料类型，可选: '硅' 或 '碳化硅'")

def multi_beam_interference(wavenumber, thickness, r1, r2, n, theta):
    """
    多光束干涉模型计算反射率
    wavenumber: 波数(cm⁻¹)
    thickness: 厚度(μm)
    r1, r2: 反射系数
    n: 材料折射率
    theta: 入射角(弧度)
    """
    wavelength = 10000 / wavenumber  # 转换为μm
    k0 = 2 * math.pi / wavelength    # 真空波数
    
    # 相位差计算
    delta = 2 * k0 * n * thickness * math.cos(theta)
    
    # 多光束干涉反射率公式
    numerator = r1 + r2 * np.exp(-1j * delta)
    denominator = 1 + r1 * r2 * np.exp(-1j * delta)
    reflectance = np.abs(numerator / denominator) **2
    
    return np.real(reflectance)

def fit_interference_model(peaks_v, peaks_R, material, theta0=10):
    """拟合干涉模型获取参数"""
    theta0_rad = math.radians(theta0)
    
    # 定义拟合函数
    def model_func(v, thickness, r1, r2):
        n = refractive_index(10**4 / v, material)
        return multi_beam_interference(v, thickness, r1, r2, n, theta0_rad)
    
    # 初始猜测值
    initial_guess = [1.0, 0.3, 0.3]  # 厚度, r1, r2
    
    # 曲线拟合
    popt, pcov = curve_fit(
        model_func, 
        peaks_v, 
        peaks_R, 
        p0=initial_guess,
        bounds=([0.1, 0, 0], [10.0, 1, 1])  # 参数边界
    )
    
    # 计算R²值
    y_pred = model_func(peaks_v, *popt)
    ss_res = np.sum((peaks_R - y_pred) **2)
    ss_tot = np.sum((peaks_R - np.mean(peaks_R))** 2)
    r_squared = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0
    
    # 计算置信区间
    perr = np.sqrt(np.diag(pcov))
    confidence_interval = 1.96 * perr  # 95%置信区间
    
    return {
        'thickness': popt[0],
        'r1': popt[1],
        'r2': popt[2],
        'thickness_error': perr[0],
        'r1_error': perr[1],
        'r2_error': perr[2],
        'r_squared': r_squared,
        'confidence_interval': confidence_interval
    }

def sensitivity_analysis(fit_results, peaks_v, peaks_R, theta0=10, n_samples=100, material="碳化硅"):
    """执行灵敏度分析"""
    theta0_rad = math.radians(theta0)
    
    # 参数变化范围
    h_values = np.linspace(fit_results['thickness']*0.9, fit_results['thickness']*1.1, 20)
    r1_values = np.linspace(max(0, fit_results['r1']-0.1), min(1, fit_results['r1']+0.1), 20)
    r2_values = np.linspace(max(0, fit_results['r2']-0.1), min(1, fit_results['r2']+0.1), 20)
    
    # 生成厚度样本
    h_samples = np.random.normal(fit_results['thickness'], fit_results['thickness_error'], n_samples)
    r_squared_samples = []
    
    for h in h_samples:
        # 计算模型值
        model_vals = np.array([
            multi_beam_interference(
                v, h, fit_results['r1'], fit_results['r2'], 
                refractive_index(10**4 / v, material), theta0_rad
            ) for v in peaks_v
        ])
        
        # 计算残差和R² (修复列表相减问题)
        residuals = np.array(peaks_R) - model_vals
        ss_res = np.sum(residuals**2)
        ss_tot = np.sum((np.array(peaks_R) - np.mean(peaks_R))** 2)
        r_squared = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0
        r_squared_samples.append(r_squared)
    
    # 绘制灵敏度分析图
    plt.figure(figsize=(15, 5))
    
    plt.subplot(1, 3, 1)
    plt.plot(h_values, [np.mean(r_squared_samples)]*len(h_values), 'b-')
    plt.fill_between(
        h_values, 
        np.percentile(r_squared_samples, 5), 
        np.percentile(r_squared_samples, 95), 
        color='b', alpha=0.2
    )
    plt.xlabel('厚度 (μm)')
    plt.ylabel('R²')
    plt.title('厚度灵敏度分析')
    plt.axvline(x=fit_results['thickness'], color='r', linestyle='--', label='最佳拟合值')
    plt.legend()
    
    plt.subplot(1, 3, 2)
    r1_r2 = [multi_beam_interference(
        v, fit_results['thickness'], r1, fit_results['r2'],
        refractive_index(10**4 / v, material), theta0_rad
    ) for r1 in r1_values for v in peaks_v]
    r1_r2 = np.array(r1_r2).reshape(len(r1_values), len(peaks_v))
    r1_r2_avg = np.mean(r1_r2, axis=1)
    plt.plot(r1_values, [fit_results['r_squared']]*len(r1_values), 'r-')
    plt.xlabel('r1')
    plt.ylabel('R²')
    plt.title('r1灵敏度分析')
    plt.axvline(x=fit_results['r1'], color='r', linestyle='--', label='最佳拟合值')
    plt.legend()
    
    plt.subplot(1, 3, 3)
    r2_r2 = [multi_beam_interference(
        v, fit_results['thickness'], fit_results['r1'], r2,
        refractive_index(10**4 / v, material), theta0_rad
    ) for r2 in r2_values for v in peaks_v]
    r2_r2 = np.array(r2_r2).reshape(len(r2_values), len(peaks_v))
    r2_r2_avg = np.mean(r2_r2, axis=1)
    plt.plot(r2_values, [fit_results['r_squared']]*len(r2_values), 'g-')
    plt.xlabel('r2')
    plt.ylabel('R²')
    plt.title('r2灵敏度分析')
    plt.axvline(x=fit_results['r2'], color='r', linestyle='--', label='最佳拟合值')
    plt.legend()
    
    plt.tight_layout()
    plt.show()
    
    return {
        'thickness_range': (np.min(h_samples), np.max(h_samples)),
        'r_squared_range': (np.min(r_squared_samples), np.max(r_squared_samples)),
        'confidence_interval': fit_results['confidence_interval']
    }

# 示例使用
if __name__ == "__main__":
    # 生成示例数据
    np.random.seed(42)  # 设置随机种子，保证结果可复现
    peaks_v = np.linspace(1000, 3000, 20)  # 波数范围
    
    # 生成带噪声的反射率数据
    true_thickness = 2.5
    true_r1 = 0.35
    true_r2 = 0.25
    material = "硅"
    theta0 = 10
    
    # 计算理论反射率并添加噪声
    theta_rad = math.radians(theta0)
    peaks_R = [
        multi_beam_interference(
            v, true_thickness, true_r1, true_r2,
            refractive_index(10**4 / v, material), theta_rad
        ) + np.random.normal(0, 0.02)  # 添加噪声
        for v in peaks_v
    ]
    
    # 拟合模型
    fit_results = fit_interference_model(peaks_v, peaks_R, material, theta0)
    print("拟合结果:")
    print(f"厚度: {fit_results['thickness']:.4f} μm (误差: {fit_results['thickness_error']:.4f})")
    print(f"r1: {fit_results['r1']:.4f} (误差: {fit_results['r1_error']:.4f})")
    print(f"r2: {fit_results['r2']:.4f} (误差: {fit_results['r2_error']:.4f})")
    print(f"R²值: {fit_results['r_squared']:.4f}")
    
    # 执行灵敏度分析
    sens_results = sensitivity_analysis(
        fit_results, 
        peaks_v, 
        peaks_R, 
        theta0=theta0,
        material=material
    )
    
    print("\n灵敏度分析结果:")
    print(f"厚度变化范围: {sens_results['thickness_range'][0]:.4f} - {sens_results['thickness_range'][1]:.4f} μm")
    print(f"R²值变化范围: {sens_results['r_squared_range'][0]:.4f} - {sens_results['r_squared_range'][1]:.4f}")
