def optimize_parameters(peak_wavelengths, delta_λ, theta0=10):
    """优化计算a,b,d参数(采用多初始点优化，同时增强折射率约束)"""
    theta0_rad = math.radians(theta0)
    
    # 待优化的目标函数1：理论波长差公式
    def objective1(params): 
        a, b, d = params
        theta0_rad = math.radians(10)  # 按题目要求入射角固定为10°
        error = 0
        start_idx = 7     #区间可以动态调整，防止边缘峰干扰，增大误差
        end_idx = len(peak_wavelengths) - 2
        
        for i in range(start_idx, end_idx): 
            λ1, λ2 = peak_wavelengths[i], peak_wavelengths[i+1]  
            n1_sq = a - b * λ1**2  
            n2_sq = a - b * λ2**2  
            
            # 计算根号下的式子(加入判断确保根号下非负)
            term1 = math.sqrt(n1_sq - math.sin(theta0_rad)**2) if n1_sq > math.sin(theta0_rad)**2 else 0
            term2 = math.sqrt(n2_sq - math.sin(theta0_rad)**2) if n2_sq > math.sin(theta0_rad)**2 else 0
            
            if term1 == 0 or term2 == 0:
                return float('inf')  # 没有物理意义，进行惩罚程序
            
            # 核心公式：理论和实际的级次差都为1
            left = 2 * d * term2 / λ2
            right = 2 * d * term1 / λ1
            theory_diff = left - right    
            actual_diff = 1             
            error += (theory_diff - actual_diff) **2  # 对平方误差累计求和
        return error 
    
    # 目标函数2：增强对折射率约束(用指数级惩罚来确保物理合理性)
    def objective2(params):
        a, b, _ = params
        penalty = 0
        for λ in peak_wavelengths:
            n_sq = a - b * λ**2  
            if n_sq < 1.0**2:  # 检测折射率平方是否小于1(不符合实际就要约束)
                # 指数级惩罚：n越小，惩罚增长越快
                penalty += 100 * np.exp(10 * (1 - n_sq))  
            if n_sq < 0:  # 避免开方为负
                penalty += 1e15  # 更严重的惩罚
        return penalty
    
    # 多目标优化（增强约束权重）
    def multi_objective(params):
        return objective1(params) + 0.5 * objective2(params)  # 约束权重设定为0.5
    
    # 筛选最优结果
    best_result = None
    best_fun = float('inf')
    for guess in initial_guesses:
        res = minimize(
            multi_objective, 
            guess, 
            bounds=bounds, 
            method='SLSQP',    #选择序列最小二乘规划解决带约束非线性优化问题
            options={'maxiter': 5000, 'ftol': 1e-10, 'eps': 1e-6}
        )
        if res.success and res.fun < best_fun:
            best_fun = res.fun
            best_result = res



def sensitivity_analysis(optimal_params, peak_wavelengths, delta_λ, theta0=10):
    """偏导数法的灵敏度分析"""
    a, b, d = optimal_params['a'], optimal_params['b'], optimal_params['d']
    theta0_rad = math.radians(theta0)
    h = 1e-6  # 微小的扰动步长
    
    print("\n=== 偏导法参数灵敏度分析 ===")
    
    # 计算原始误差
    original_error = calculate_error(a, b, d, peak_wavelengths, delta_λ, theta0_rad)
    
    # 计算a的偏导数
    error_a_plus = calculate_error(a + h, b, d, peak_wavelengths, delta_λ, theta0_rad)
    a_partial_deriv = (error_a_plus - original_error) / h
    
    # 计算b的偏导数
    error_b_plus = calculate_error(a, b + h, d, peak_wavelengths, delta_λ, theta0_rad)
    b_partial_deriv = (error_b_plus - original_error) / h
    
    # 计算d的偏导数
    error_d_plus = calculate_error(a, b, d + h, peak_wavelengths, delta_λ, theta0_rad)
    d_partial_deriv = (error_d_plus - original_error) / h
    
    # 归一化处理
    norm_partial_a = abs(a_partial_deriv * a / original_error)
    norm_partial_b = abs(b_partial_deriv * b / original_error)
    norm_partial_d = abs(d_partial_deriv * d / original_error)
    
    print("\n参数灵敏度(偏导):")
    print(f"参数a的偏导数: {a_partial_deriv:.4e}")
    print(f"参数b的偏导数: {b_partial_deriv:.4e}")
    print(f"参数d的偏导数: {d_partial_deriv:.4e}")
    
    print("\n归一化灵敏度(弹性系数):")
    print(f"参数a的弹性系数: {norm_partial_a:.4f}")
    print(f"参数b的弹性系数: {norm_partial_b:.4f}")
    print(f"参数d的弹性系数: {norm_partial_d:.4f}")

def calculate_error(a, b, d, peak_wavelengths, delta_λ, theta0_rad):
    """计算固定参数下的累计误差"""
    error = 0      #误差先初始化
    start_idx = 7
    end_idx = len(peak_wavelengths) - 2
    
    for i in range(start_idx, end_idx):
        λ1, λ2 = peak_wavelengths[i], peak_wavelengths[i+1]
        n1_sq = a - b * λ1**2
        n2_sq = a - b * λ2**2
        
        term1 = math.sqrt(n1_sq - math.sin(theta0_rad)**2) if n1_sq > math.sin(theta0_rad)**2 else 0
        term2 = math.sqrt(n2_sq - math.sin(theta0_rad)**2) if n2_sq > math.sin(theta0_rad)**2 else 0
        
        if term1 == 0 or term2 == 0:
            return float('inf')
            
        left = 2 * d * term2 / λ2
        right = 2 * d * term1 / λ1
        theory_diff = left - right
        error += (theory_diff - 1) ** 2
        
    return error

# 执行优化和灵敏度分析
if __name__ == "__main__":
    result, params = optimize_parameters(attach1_peak_λ, attach1_delta_λ)
    
    sensitivity_analysis(params, attach1_peak_λ, attach1_delta_λ)