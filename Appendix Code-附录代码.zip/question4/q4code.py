def refractive_index(λ):
    """计算碳化硅折射率 - Sellmeier方程"""
    #根据文献参考得到的数据
    B1, B2, B3 = 5.551, 0.213, 2.967
    C1, C2, C3 = 0.00502, 0.01408, 417.5
    
    #并行计算
    term1 = (B1 * λ**2) / (λ**2 - C1)
    term2 = (B2 * λ**2) / (λ**2 - C2) 
    term3 = (B3 * λ**2) / (λ**2 - C3)
    
    n = np.sqrt(1 + term1 + term2 + term3)
    return n

def load_and_preprocess(file_path, min_height=0.6, min_distance=50):
    """读取并预处理数据"""
    try:
        # 读取数据
        df = pd.read_excel(file_path, header=None)
        df.columns = ["v", "R"]  # 简单列命名
        
        # 基本数据清洗
        df = df.dropna()
        df = df[(df["v"] > 500) & (df["v"] < 10000)]
        
        # 计算波长
        df["λ"] = 10000 / df["v"]  # 转换为μm
        
        # 通过find_peaks函数筛选找到合理峰值
        peaks_idx, _ = find_peaks(df["R"], height=min_height, distance=min_distance)
        
        # 提取峰值数据
        peaks = df.iloc[peaks_idx]
        peaks_v = peaks["v"].values
        peaks_R = peaks["R"].values
        peaks_λ = peaks["λ"].values
    
        peaks_v = df.iloc[peaks_idx]["v"].values
        peaks_R = df.iloc[peaks_idx]["R"].values
        peaks_λ = df.iloc[peaks_idx]["λ"].values
    
        # 计算相邻峰波长差
        delta_λ = np.diff(peaks_λ)
    
        return df, peaks_idx, peaks_v, peaks_R, peaks_λ, delta_λ, np.diff(peaks_λ)

def multi_beam_interference(v, h, r1, r2, n, theta0_rad):
    """多光束干涉模型(考虑多次反射)"""
    λ = 10**4 / v  # 波长(μm)
    sin_theta = np.sin(theta0_rad)
    
    # 使用向量化操作替代条件判断，避免歧义
    cos_theta = np.where(n > sin_theta, 
                        np.sqrt(1 - (sin_theta/n)**2), 
                        np.zeros_like(n))
    
    delta = 4 * math.pi * n * h * cos_theta / λ
    R = (r1**2 + r2**2 - 2*r1*r2*np.cos(delta)) / (1 + (r1*r2)**2 - 2*r1*r2*np.cos(delta))
    return R * 100  # 转换为百分比

def multiple_reflection_fit(peaks_λ, peaks_v, peaks_R, theta0=10):
    """拟合函数"""
    theta_rad = math.radians(theta0)
    
    # 定义模型函数
    def model(v, h, r1, r2):
        λ = 10000 / v
        n = refractive_index(λ)
        cos_theta = math.sqrt(1 - (math.sin(theta_rad)/n)**2)
        delta = 4 * math.pi * n * h * cos_theta / λ
        R = (r1**2 + r2**2 - 2*r1*r2*math.cos(delta)) / (1 + (r1*r2)**2 - 2*r1*r2*math.cos(delta))
        return R * 100
    
    # 对参数的值进行预估
    h_guess = 10.0
    r1_guess = 0.2
    r2_guess = 0.3
    
    try:
        # 进行拟合的过程
        popt, _ = curve_fit(model, peaks_v, peaks_R, p0=[h_guess, r1_guess, r2_guess])
        h_fit, r1_fit, r2_fit = popt
        
        # 计算R平方
        residuals = peaks_R - model(peaks_v, *popt)
        ss_res = np.sum(residuals**2)
        ss_tot = np.sum((peaks_R - np.mean(peaks_R))**2)
        r_squared = 1 - (ss_res / ss_tot)
        
        return h_fit, r_squared, {
            'thickness': h_fit,
            'r1': r1_fit,
            'r2': r2_fit,
            'r_squared': r_squared
        }
    except:
        print("拟合失败")
        return None, None, None
    
        #改进的初始参数估计
        r1_guess = 0.25  # 优化后的初始反射系数估计
        r2_guess = 0.35
        h_guess = 10.0  # 根据碳化硅典型厚度得出
    
    try:
        peaks_v = np.asarray(peaks_v).flatten()
        peaks_R = np.asarray(peaks_R).flatten()
        
        # 使用Levenberg-Marquardt算法优化拟合
        popt, pcov = curve_fit(
            enhanced_interference_model,
            peaks_v,
            peaks_R,
            p0=[h_guess, r1_guess, r2_guess],
            bounds=([5, 0.1, 0.1], [20, 0.5, 0.5]),  # 合理的参数范围
            method='trf',  # 使用信赖域反射算法
            maxfev=5000    # 最大迭代次数
        )
    except Exception as e:
        print(f"拟合过程出错: {e}")
        # 输出调试信息
        print(f" peaks_v形状: {np.shape(peaks_v)}, peaks_R形状: {np.shape(peaks_R)}")
        return None, None, None
    
    h_fit, r1_fit, r2_fit = popt
    h_error = np.sqrt(pcov[0,0])  # 厚度误差估计
    
    # 计算拟合优度
    residuals = peaks_R - enhanced_interference_model(peaks_v, h_fit, r1_fit, r2_fit)
    ss_res = np.sum(residuals**2)
    ss_tot = np.sum((peaks_R - np.mean(peaks_R))** 2)
    r_squared = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0
    
    # 计算误差估计
    confidence_interval = 1.96 * h_error  # 95%置信区间
    
    # 评估模型适用性
    def check_multiple_reflection(reflectance):
        """检查是否存在多光束干涉特征"""
        return (np.max(reflectance) - np.min(reflectance)) > 30  # 30%作为阈值
    
    use_multi_beam = check_multiple_reflection(peaks_R) if len(peaks_R) > 0 else False
    
    fit_results = {
        'thickness': h_fit,
        'thickness_error': h_error,
        'confidence_interval': (h_fit - confidence_interval, h_fit + confidence_interval),
        'r1': r1_fit,
        'r2': r2_fit,
        'r_squared': r_squared,
        'peaks_used': len(peaks_v),
        'wavelength_range': (np.min(peaks_λ), np.max(peaks_λ)) if len(peaks_λ) > 0 else (0, 0),
        'multi_beam_detected': use_multi_beam
    }
    
    return h_fit, r_squared, fit_results

def analyze_attachment(file_path):
    """分析单个附件数据并计算厚度"""
    # 根据题目要求确定入射角
    if "附件1" in file_path:
        theta0 = 10  # 题目说明附件1入射角为10°
        material = "碳化硅"
    elif "附件2" in file_path:
        theta0 = 15  # 题目说明附件2入射角为15°
        material = "碳化硅"
    elif "附件3" in file_path:
        theta0 = 10
        material = "硅"
    elif "附件4" in file_path:
        theta0 = 15
        material = "硅"
    else:
        theta0 = 10
        material = "未知材料"
    
    # 使用多次反射干涉模型计算厚度
    h_fit, r_squared, fit_results = multiple_reflection_fit(peaks_λ, peaks_v, peaks_R, theta0)
    if fit_results is None:
     return None
    
    # 打印结果
    print(f"\n{file_path} 分析结果(材料: {material}, 入射角 {theta0}°):")
    print(f"检测到的干涉峰数量: {len(peaks_v)}")
    print(f"计算厚度: {h_fit:.4f} μm")
    print(f"95%置信区间: ({fit_results['confidence_interval'][0]:.4f}, {fit_results['confidence_interval'][1]:.4f}) μm")
    print(f"拟合优度 R²: {r_squared:.4f}")
    if fit_results['multi_beam_detected']:
        print("检测到多光束干涉特征")
    
    return fit_results

if __name__ == "__main__":
    print("碳化硅外延层厚度分析:")
    try:
        # 分析附件1(10°入射角)
        print("\n分析附件1(10°入射角):")
        siC_10deg = analyze_attachment("附件1.xlsx")
        
        # 分析附件2(15°入射角)
        print("\n分析附件2(15°入射角):")
        siC_15deg = analyze_attachment("附件2.xlsx")
        
        # 计算平均厚度
        if siC_10deg and siC_15deg:
            avg_thickness = (siC_10deg['thickness'] + siC_15deg['thickness']) / 2
            print(f"\n碳化硅外延层平均厚度: {avg_thickness:.4f} μm")
    except Exception as e:
        print(f"分析过程中发生错误: {str(e)}")
    
