# 本论文运行环境为Python，版本为 3.12.11
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import find_peaks
from scipy.optimize import minimize, dual_annealing
import math
import cmath

def process_and_find_peaks(spectral_data_path, 
    min_height=0.6, 
    min_distance=50, 
    prominence=0.3
):
    """先读取附件中数据并进行干涉峰的动态检测"""
    #读取Excel表格数据，同时将列名指定为波数("v")和反射率("R")
    df = pd.read_excel(spectral_data_path, header=None, names=["v", "R"])

    # 旨在一条龙实现“类型转换→去缺失→排序→重置索引”的整合，
    # 把数据类型转换
    df[['v', 'R']] = df[['v', 'R']].apply(pd.to_numeric, errors='coerce')

    # 剔除无效值
    df = df.dropna(subset=['v', 'R'])

    # 排序并把索引重新设置
    df = df.sort_values('v').reset_index(drop=True)

    # 添加波长列，同时在使用公式时顺便进行了单位的转换
    df["λ"] = 1e4 / df["v"]      
    # 基于v[cm⁻¹] = 10⁴/λ[μm] 的光谱学定义，我们得到了波长转换公式：λ[μm] = 10⁴/v[cm⁻¹]
    
    # 2. 动态检测干涉峰
    # 设置参数可自动调整，直到找到合理数量的峰(预估5-30个为合理的可接受的范围)，随即终止
    #为了避免变量操作太过分散，我们采用封装存储策略，利用params字典以及adjust字典分别集中管理可调整参数和对应的调整因子
    params = {'min_h': min_height, 'min_d': min_distance}   
    adjust = {'under': (0.9, 0.8), 'over': (1.1, 1.2)}     
    peaks_idx, properties = [], {}

    for attempt in range(3):
        peaks_idx, properties = find_peaks(
            df["R"],
            height = params['min_h'],
            distance = params['min_d'],
            prominence = prominence,
            width = 20
        )

        # 检查峰数量是否是合理的，中断后可方便调参
        cnt = len(peaks_idx)
        if 5 <= cnt <= 30:
            break

        # 用元组解包实现参数调整,减少嵌套
        h_factor, d_factor= adjust['under'] if cnt < 5 else adjust['over']
        params['min_h'] *= h_factor
        params['min_d'] *= d_factor
    else:
        print("警告:找不到合理数量的干涉峰，使用目前检测结果")

    # loc可以做到批量提取峰数据，通过values.T转置后直接解包赋值，效率提升一大截
    peaks_data = df.loc[peaks_idx, ['v', 'R', 'λ']].values.T
    peaks_v, peaks_R, peaks_λ = peaks_data
    
    # 计算相邻峰波长差
    delta_λ = np.diff(peaks_λ)
    
    # 打印相邻峰波长差
    for idx, delta in enumerate(delta_λ, start=1):
        print(
    f"峰{idx}和峰{idx+1}的波长差: {delta:.4f} μm "
    f"(λ₁={peaks_λ[idx-1]:.4f} μm, λ₂={peaks_λ[idx]:.4f} μm)"
)
    return  peaks_idx, peaks_v, peaks_R, peaks_λ, delta_λ ,df

# 处理附件1(替换附件二同理)数据（本论文已经优化了参数的管理方式，还是用字典封装）
attach1_params = {
    "spectral_data_path": "附件1.xlsx",
    "min_height": 0.8,
    "min_distance": 80,
    "prominence": 0.3
}

#函数一次返回多个结果
(attach1_peak_idx, attach1_peak_v, attach1_peak_R, 
attach1_peak_λ, attach1_delta_λ, attach1_df ) = process_and_find_peaks(**attach1_params)


