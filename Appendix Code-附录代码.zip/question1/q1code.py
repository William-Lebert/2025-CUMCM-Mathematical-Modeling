# 本论文运行环境为Python，版本为 3.12.11
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import find_peaks
from scipy.optimize import minimize, dual_annealing
import math
import cmath

def process_and_find_peaks(spectral_data_path, 
    min_height=0.6, 
    min_distance=50, 
    prominence=0.3
):
    """先读取附件中数据并进行干涉峰的动态检测"""
    #读取Excel表格数据，同时将列名指定为波数("v")和反射率("R")
    df = pd.read_excel(spectral_data_path, header=None, names=["v", "R"])

    # 旨在一条龙实现“类型转换→去缺失→排序→重置索引”的整合，
    # 把数据类型转换
    df[['v', 'R']] = df[['v', 'R']].apply(pd.to_numeric, errors='coerce')

    # 剔除无效值
    df = df.dropna(subset=['v', 'R'])

    # 排序并把索引重新设置
    df = df.sort_values('v').reset_index(drop=True)

    # 添加波长列，同时在使用公式时顺便进行了单位的转换
    df["λ"] = 1e4 / df["v"]      
    # 基于v[cm⁻¹] = 10⁴/λ[μm] 的光谱学定义，我们得到了波长转换公式：λ[μm] = 10⁴/v[cm⁻¹]
    
    # 2. 动态检测干涉峰
    # 设置参数可自动调整，直到找到合理数量的峰(预估5-30个为合理的可接受的范围)，随即终止
    #为了避免变量操作太过分散，我们采用封装存储策略，利用params字典以及adjust字典分别集中管理可调整参数和对应的调整因子
    params = {'min_h': min_height, 'min_d': min_distance}   
    adjust = {'under': (0.9, 0.8), 'over': (1.1, 1.2)}     
    peaks_idx, properties = [], {}

    for attempt in range(3):
        peaks_idx, properties = find_peaks(
            df["R"],
            height = params['min_h'],
            distance = params['min_d'],
            prominence = prominence,
            width = 20
        )

        # 检查峰数量是否是合理的，中断后可方便调参
        cnt = len(peaks_idx)
        if 5 <= cnt <= 30:
            break

        # 用元组解包实现参数调整,减少嵌套
        h_factor, d_factor= adjust['under'] if cnt < 5 else adjust['over']
        params['min_h'] *= h_factor
        params['min_d'] *= d_factor
    else:
        print("警告:找不到合理数量的干涉峰，使用目前检测结果")

    # loc可以做到批量提取峰数据，通过values.T转置后直接解包赋值，效率提升一大截
    peaks_data = df.loc[peaks_idx, ['v', 'R', 'λ']].values.T
    peaks_v, peaks_R, peaks_λ = peaks_data
    
    # 计算相邻峰波长差
    delta_λ = np.diff(peaks_λ)
    
    # 打印相邻峰波长差
    for idx, delta in enumerate(delta_λ, start=1):
        print(
    f"峰{idx}和峰{idx+1}的波长差: {delta:.4f} μm "
    f"(λ₁={peaks_λ[idx-1]:.4f} μm, λ₂={peaks_λ[idx]:.4f} μm)"
)
    return  peaks_idx, peaks_v, peaks_R, peaks_λ, delta_λ ,df

# 处理附件1(替换附件二同理)数据（本论文已经优化了参数的管理方式，还是用字典封装）
attach1_params = {
    "spectral_data_path": "附件1.xlsx",
    "min_height": 0.8,
    "min_distance": 80,
    "prominence": 0.3
}

#函数一次返回多个结果
(attach1_peak_idx, attach1_peak_v, attach1_peak_R, 
attach1_peak_λ, attach1_delta_λ, attach1_df ) = process_and_find_peaks(**attach1_params)

def optimize_parameters(peak_wavelengths, delta_λ, theta0=10):
    """优化计算a,b,d参数(采用多初始点优化，同时增强折射率约束)"""
    theta0_rad = math.radians(theta0)
    
    # 待优化的目标函数1：理论波长差公式
    def objective1(params): 
        a, b, d = params
        theta0_rad = math.radians(10)  # 按题目要求入射角固定为10°
        error = 0
        start_idx = 7     #区间可以动态调整，防止边缘峰干扰，增大误差
        end_idx = len(peak_wavelengths) - 2
        
        for i in range(start_idx, end_idx): 
            λ1, λ2 = peak_wavelengths[i], peak_wavelengths[i+1]  
            n1_sq = a - b * λ1**2  
            n2_sq = a - b * λ2**2  
            
            # 计算根号下的式子(加入判断确保根号下非负)
            term1 = math.sqrt(n1_sq - math.sin(theta0_rad)**2) if n1_sq > math.sin(theta0_rad)**2 else 0
            term2 = math.sqrt(n2_sq - math.sin(theta0_rad)**2) if n2_sq > math.sin(theta0_rad)**2 else 0
            
            if term1 == 0 or term2 == 0:
                return float('inf')  # 没有物理意义，进行惩罚程序
            
            # 核心公式：理论和实际的级次差都为1
            left = 2 * d * term2 / λ2
            right = 2 * d * term1 / λ1
            theory_diff = left - right    
            actual_diff = 1             
            error += (theory_diff - actual_diff) **2  # 对平方误差累计求和
        return error 
    
    # 目标函数2：增强对折射率约束(用指数级惩罚来确保物理合理性)
    def objective2(params):
        a, b, _ = params
        penalty = 0
        for λ in peak_wavelengths:
            n_sq = a - b * λ**2  
            if n_sq < 1.0**2:  # 检测折射率平方是否小于1(不符合实际就要约束)
                # 指数级惩罚：n越小，惩罚增长越快
                penalty += 100 * np.exp(10 * (1 - n_sq))  
            if n_sq < 0:  # 避免开方为负
                penalty += 1e15  # 更严重的惩罚
        return penalty
    
    # 多目标优化（增强约束权重）
    def multi_objective(params):
        return objective1(params) + 0.5 * objective2(params)  # 约束权重设定为0.5
    
    # 多初始点优化
    initial_guesses = [
        [3.1, 0.0016, 9.36],   
        [4.9, 0.0030, 10.23],
        [5.8, 0.0065, 11.81]
    ]
    
    bounds = [
        (1.5, 6.5),       # 要确保a - bλ² ≥ 1（λ最大时，a需足够大）符合物理意义(折射率≥1)
        (0.0005, 0.008),  # 降低b的上限可以减缓n²的下降速度
        (9.0, 12.0 )      # 厚度d的范围
    ]
    
    # 筛选最优结果
    best_result = None
    best_fun = float('inf')
    for guess in initial_guesses:
        res = minimize(
            multi_objective, 
            guess, 
            bounds=bounds, 
            method='SLSQP',    #选择序列最小二乘规划解决带约束非线性优化问题
            options={'maxiter': 5000, 'ftol': 1e-10, 'eps': 1e-6}
        )
        if res.success and res.fun < best_fun:
            best_fun = res.fun
            best_result = res
    
    if best_result is None:
        raise ValueError("所有初始点优化均失败，请检查参数范围或数据")
    
    optimal_params = {            #使用字典存储待优化参数
        'a': best_result.x[0],
        'b': best_result.x[1],
        'd': best_result.x[2]
    }
    
    # 优化后验证折射率合理性 + 可视化折射率分布
    n_values = [math.sqrt(optimal_params['a'] - optimal_params['b'] * λ**2) for λ in peak_wavelengths]  
    print("\n折射率范围验证:")
    print(f"最小折射率: {min(n_values):.4f}")
    print(f"最大折射率: {max(n_values):.4f}")
    if any(n < 1.0 for n in n_values):
        print("警告：仍存在折射率<1的不合理值,需进一步调整！")
    else:
        print("折射率全部≥1,物理合理！")
    
    # 优化后验证折射率合理性
    n_values = [math.sqrt(optimal_params['a'] - optimal_params['b'] * λ**2) for λ in peak_wavelengths]  # 补全平方
    print("\n折射率范围验证:")
    print(f"最小折射率: {min(n_values):.4f}")
    print(f"最大折射率: {max(n_values):.4f}")
    if any(n < 1.0 for n in n_values):
        print("警告：存在折射率<1的不合理值,建议调整参数范围!")
    
    # 输出优化结果
    print("\n优化结果:")
    print(f"最优参数 a: {optimal_params['a']:.4f}")
    print(f"最优参数 b: {optimal_params['b']:.6f}")
    print(f"最优外延层厚度 d: {optimal_params['d']:.4f} μm")
    print(f"优化状态: {'成功' if best_result.success else '失败'}")
    print(f"目标函数值: {best_result.fun:.4e}")

# 调用优化函数并输出厚度结果
optimal_params = optimize_parameters(attach1_peak_λ, attach1_delta_λ)
print(f"\n优化得到的外延层厚度 d: {optimal_params['d']:.4f} μm")

