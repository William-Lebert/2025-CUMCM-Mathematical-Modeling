def load_and_preprocess(spectral_data_path):
    """数据加载函数"""
    df = pd.read_excel(spectral_data_path, header=None, names=["v", "R"], engine='openpyxl')
    df = df.apply(pd.to_numeric, errors='coerce').dropna()
    df = df.sort_values("v").reset_index(drop=True)
    # 将百分比的反射率数据转换为小数
    df["R"] = df["R"] / 100.0
    
    # 使用Savitzky-Golay滤波器进行数据平滑处理
    from scipy.signal import savgol_filter
    window_size = 21      # 窗口大小(奇数)
    poly_order = 3        # 多项式阶数
    df["R"] = savgol_filter(df["R"], window_size, poly_order)
    
    df["λ"] = 10**4 / df["v"]
    return df, df["v"].values, df["R"].values, df["λ"].values

def calculate_fresnel_coefficients(n1, n2, theta0=10):
    """菲涅耳系数计算"""
    theta0_rad = math.radians(theta0)
    sin_theta1 = math.sin(theta0_rad) / n1
    cos_theta1 = cmath.sqrt(1 - sin_theta1**2) if abs(1 - sin_theta1**2) > 0 else 0
    
    r1s = (math.cos(theta0_rad) - n1 * cos_theta1) / (math.cos(theta0_rad) + n1 * cos_theta1)
    r1p = (n1 * math.cos(theta0_rad) - cos_theta1) / (n1 * math.cos(theta0_rad) + cos_theta1)
    r1 = cmath.sqrt((r1s**2 + r1p**2)/2)
    
    sin_theta2 = math.sin(theta0_rad) / n2
    cos_theta2 = cmath.sqrt(1 - sin_theta2**2) if abs(1 - sin_theta2**2) > 0 else 0
    
    r2s = (n1 * cos_theta1 - n2 * cos_theta2) / (n1 * cos_theta1 + n2 * cos_theta2)
    r2p = (n2 * cos_theta1 - n1 * cos_theta2) / (n2 * cos_theta1 + n1 * cos_theta2)
    r2 = cmath.sqrt((r2s**2 + r2p**2)/2)
    
    return r1, r2

class SiCOpticalModel:
    """构建SiC的光学模型"""
    def __init__(self, m_eff, N, omega_p, a=6.52):    #定义相关光学参数
        self.a = a
        self.m_eff = m_eff
        self.N = N
        self.omega_p = omega_p

    def set_carrier_params(self, N, m_eff, mu=1):  #规定载流子浓度为1
        e = 4.8e-10
        self.omega_p = math.sqrt(N * e**2 /8.85e-12 * m_eff)
        self.gamma = e/(m_eff * mu)   
    
    def dielectric_function(self, wavelength):
        wavenumber = 1e4 / wavelength      #波数与波长的相互转换
        omega = 2 * math.pi * 3e14 * wavenumber
        eps_carrier = -self.omega_p**2 / (omega * (omega + 1j*self.gamma)) if self.omega_p > 0 else 0
        return self.a * (1 + eps_carrier)

def global_fit_refractive_index(measured_R, wavelengths, theta0=10):
    """全局拟合函数，添加进度显示"""
    bounds = [
        (3.0, 6.0),       # 厚度d的范围(μm)
        (5e16, 5e17),      # 载流子浓度范围(cm⁻³)
        (1.82e-31, 6.83e-31),   # 有效质量范围
        (3, 10),          # 衬底折射率
        (6.5, 6.9)       # 参数a的范围
    ]
    
    model = SiCOpticalModel(m_eff=1.0, N=5e17, omega_p=0)     #先对模型进行变量初始化
        
    res = dual_annealing(    #双退火算法可以一边模拟退火，一边局部搜索，避免局部最优
            objective,
            bounds=bounds,
            maxiter=200,
            initial_temp=3000,
            visit=2.5,
            accept=-5.0,
            no_local_search=False
        )
    
    # 求出最优结果
    d_opt, N_opt, m_eff_opt, n2_opt, a_opt = res.x
    model.set_carrier_params(N=N_opt, m_eff=m_eff_opt)
    model.a = a_opt
    
    n1_values = []
    for λ in wavelengths:
        eps = model.dielectric_function(λ)
        n1_values.append(cmath.sqrt(eps))
    
    return {
        'n1': n1_values,
        'n2': n2_opt,
        'd': d_opt,
        'N': N_opt,
        'm_eff': m_eff_opt,
        'a': a_opt,
        'success': res.success,
        'message': res.message,
        'rmse': math.sqrt(abs(res.fun))    #取绝对值目的是确保平方根计算有理化
    }

def calculate_reflectivity(n1, n2, d, wavelength, theta0=10):
    """反射率计算"""
    n1_complex = complex(n1) if not isinstance(n1, complex) else n1
    n2_complex = complex(n2) if not isinstance(n2, complex) else n2
    
    r1, r2 = calculate_fresnel_coefficients(n1_complex, n2_complex, theta0)
    delta = calculate_phase_difference(n1_complex, d, wavelength, theta0)
    
    numerator = (r1**2 + r2**2) + 2 * r2 * r1 * np.cos(cmath.exp(1j * delta))
    denominator = 1 + 2 * r2 * r1 * np.cos(cmath.exp(1j * delta)) + (r1 * r2)**2
    return (numerator / denominator)

def calculate_phase_difference(n1, d, wavelength, theta0=10):
    """相位差计算"""
    theta0_rad = math.radians(theta0)
    sin_theta1 = math.sin(theta0_rad) / n1
    cos_theta1 = cmath.sqrt(1 - sin_theta1**2) if abs(1 - sin_theta1**2) > 0 else 0
    delta = (4 * cmath.pi * n1 * d * cos_theta1) / wavelength + cmath.pi
    return delta

if __name__ == "__main__":
    # 将附件数据导入
    df, v, R, λ = load_and_preprocess("附件3.xlsx")
    
    print("开始进行优化计算...")
    result = global_fit_refractive_index(R, λ)
    
    print("\n最终拟合结果:")
    print(f"衬底折射率 n2: {result['n2']:.4f}")
    print(f"外延层厚度 d: {result['d']:.4f} μm")
    print(f"载流子浓度 N: {result['N']:.2e} cm⁻³")
    print(f"有效质量 m_eff: {result['m_eff']:.4f}")
    print(f"拟合RMSE: {result['rmse']:.6f}")
    print(f"优化状态: {'成功' if result['success'] else '失败'} - {result['message']}")
