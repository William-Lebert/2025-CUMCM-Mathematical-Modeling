import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import dual_annealing
import math
import cmath
from tqdm import tqdm

def load_and_preprocess(file_path):
    """数据加载函数"""
    df = pd.read_excel(file_path, header=None, names=["v", "R"], engine='openpyxl')
    df = df.apply(pd.to_numeric, errors='coerce').dropna()
    df = df.sort_values("v").reset_index(drop=True)
    # 将百分比反射率转换为小数
    df["R"] = df["R"] / 100.0
    
    # 使用Savitzky-Golay滤波器进行数据平滑处理
    from scipy.signal import savgol_filter
    window_size = 21  # 窗口大小(奇数)
    poly_order = 3    # 多项式阶数
    df["R"] = savgol_filter(df["R"], window_size, poly_order)
    
    df["λ"] = 10**4 / df["v"]
    return df, df["v"].values, df["R"].values, df["λ"].values

def calculate_fresnel_coefficients(n1, n2, theta0=10):
    """菲涅耳系数计算"""
    theta0_rad = math.radians(theta0)
    sin_theta1 = math.sin(theta0_rad) / n1
    cos_theta1 = cmath.sqrt(1 - sin_theta1**2) if abs(1 - sin_theta1**2) > 0 else 0
    
    r1s = (math.cos(theta0_rad) - n1 * cos_theta1) / (math.cos(theta0_rad) + n1 * cos_theta1)
    r1p = (n1 * math.cos(theta0_rad) - cos_theta1) / (n1 * math.cos(theta0_rad) + cos_theta1)
    r1 = cmath.sqrt((r1s**2 + r1p**2)/2)
    
    sin_theta2 = math.sin(theta0_rad) / n2
    cos_theta2 = cmath.sqrt(1 - sin_theta2**2) if abs(1 - sin_theta2**2) > 0 else 0
    
    r2s = (n1 * cos_theta1 - n2 * cos_theta2) / (n1 * cos_theta1 + n2 * cos_theta2)
    r2p = (n2 * cos_theta1 - n1 * cos_theta2) / (n2 * cos_theta1 + n1 * cos_theta2)
    r2 = cmath.sqrt((r2s**2 + r2p**2)/2)
    
    return r1, r2

class SiCOpticalModel:
    """SiC光学模型"""
    def __init__(self, m_eff, N, omega_p, a=6.52):
        self.a = a
        self.m_eff = m_eff
        self.N = N
        self.omega_p = omega_p

    def set_carrier_params(self, N, m_eff, mu=1):
        e = 4.8e-10
        self.omega_p = math.sqrt(N * e**2 /8.85e-12 * m_eff)
        self.gamma = e/(m_eff * mu)
    
    def dielectric_function(self, wavelength):
        wavenumber = 1e4 / wavelength
        omega = 2 * math.pi * 3e14 * wavenumber
        eps_carrier = -self.omega_p**2 / (omega * (omega + 1j*self.gamma)) if self.omega_p > 0 else 0
        return self.a * (1 + eps_carrier)

def global_fit_refractive_index(measured_R, wavelengths, theta0=10):
    """全局拟合函数，添加进度显示"""
    bounds = [
        (3.86, 5.19),       # 缩小厚度范围(μm)
        (1e14, 1e21),      # 载流子浓度范围(cm⁻³)
        (1.92e-31, 6.53e-31),        # 有效质量范围
        (1, 5),         # 衬底折射率
        (6.51, 6.78)       # a参数范围
    ]
    
    model = SiCOpticalModel(m_eff=4.92e-31, N=5.79e17, omega_p=7579)
    
    # 使用tqdm显示进度
    with tqdm(total=200, desc="优化进度") as pbar:
        def objective(params):
            d, N, m_eff, n2, a = params
            model.set_carrier_params(N=N, m_eff=m_eff)
            model.a = a
            total_error = 0.0
            
            # 使用定步长遍历数据点
            step = 1  
            for i in range(3000, 4000 , step):
                λ = wavelengths[i]
                R = measured_R[i]
                
                eps_r = model.dielectric_function(λ)
                n1 = cmath.sqrt(eps_r)
                R_calc = calculate_reflectivity(n1, complex(n2, 0), d, λ, theta0)
                total_error += (R_calc - R)**2
            
            pbar.update(1)
            return total_error / (len(wavelengths) / step)
        
        res = dual_annealing(
            objective,
            bounds=bounds,
            maxiter=200,
            initial_temp=3000,
            visit=2.5,
            accept=-5.0,
            no_local_search=False
        )
    
    # 计算最优解
    d_opt, N_opt, m_eff_opt, n2_opt, a_opt = res.x
    model.set_carrier_params(N=N_opt, m_eff=m_eff_opt)
    model.a = a_opt
    
    n1_values = []
    for λ in wavelengths:
        eps = model.dielectric_function(λ)
        n1_values.append(cmath.sqrt(eps))
    
    return {
        'n1': n1_values,
        'n2': n2_opt,
        'd': d_opt,
        'N': N_opt,
        'm_eff': m_eff_opt,
        'a': a_opt,
        'success': res.success,
        'message': res.message,
        'rmse': math.sqrt(abs(res.fun))  # 取绝对值确保平方根计算有效
    }

def calculate_reflectivity(n1, n2, d, wavelength, theta0=10):
    """反射率计算"""
    n1_complex = complex(n1) if not isinstance(n1, complex) else n1
    n2_complex = complex(n2) if not isinstance(n2, complex) else n2
    
    r1, r2 = calculate_fresnel_coefficients(n1_complex, n2_complex, theta0)
    delta = calculate_phase_difference(n1_complex, d, wavelength, theta0)
    
    numerator = (r1**2 + r2**2) + 2 * r2 * r1 * np.cos(cmath.exp(1j * delta))
    denominator = 1 + 2 * r2 * r1 * np.cos(cmath.exp(1j * delta)) + (r1 * r2)**2
    return (numerator / denominator)

def calculate_phase_difference(n1, d, wavelength, theta0=10):
    """相位差计算"""
    theta0_rad = math.radians(theta0)
    sin_theta1 = math.sin(theta0_rad) / n1
    cos_theta1 = cmath.sqrt(1 - sin_theta1**2) if abs(1 - sin_theta1**2) > 0 else 0
    delta = (4 * cmath.pi * n1 * d * cos_theta1) / wavelength + cmath.pi
    return delta

if __name__ == "__main__":
    # 加载数据
    df, v, R, λ = load_and_preprocess("附件3.xlsx")
    
    print("开始优化计算...")
    result = global_fit_refractive_index(R, λ)
    
    print("\n最终拟合结果:")
    print(f"衬底折射率 n2: {result['n2']:.4f}")
    print(f"外延层厚度 d: {result['d']:.4f} μm")
    print(f"载流子浓度 N: {result['N']:.2e} cm⁻³")
    print(f"有效质量 m_eff: {result['m_eff']:.4f}")
    print(f"拟合RMSE: {result['rmse']:.6f}")
    print(f"优化状态: {'成功' if result['success'] else '失败'} - {result['message']}")
    
    # 计算并绘制R_calc与波数的关系(1750-2500 cm⁻¹)
    R_calc = []
    for i in range(len(λ)):
        R_calc.append(calculate_reflectivity(result['n1'][i], result['n2'], result['d'], λ[i]))
    
    # 筛选3000-4000波数范围
    mask = (v >= 3000) & (v <= 4000)
    v_filtered = v[mask]
    R_filtered = R[mask]
    R_calc_filtered = np.array(R_calc)[mask]
    
    plt.figure(figsize=(10, 6))
    plt.plot(v_filtered, R_calc_filtered, 'r-', label='Calculated Reflectivity')
    plt.plot(v_filtered, R_filtered, 'b.', markersize=2, label='Experimental Data')
    plt.xlabel('Wavenumber (cm$^{-1}$)')
    plt.ylabel('Reflectivity')
    plt.title('Reflectivity vs Wavenumber (3000-4000 cm$^{-1}$)')
    plt.legend()
    plt.grid(True)
    plt.savefig('reflectivity_vs_wavenumber_3000_4000.png', dpi=300)
    plt.show()