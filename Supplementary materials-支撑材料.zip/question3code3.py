import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy.signal import find_peaks
from scipy.optimize import curve_fit
import math
import warnings

# 仅设置matplotlib字体，解决特殊符号显示问题
with warnings.catch_warnings():
    warnings.simplefilter("ignore")
    plt.rcParams["font.family"] = ["SimHei"]
    plt.rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

def refractive_index(λ):
    """根据波长(μm)计算碳化硅折射率(基于Sellmeier方程)"""
    B1 = 5.551
    B2 = 0.213
    B3 = 2.967
    C1 = 0.00502
    C2 = 0.01408
    C3 = 417.5
    λ_sq = λ**2
    
    # 避免除以零或负数导致的问题，使用向量化操作
    term1 = np.where(λ_sq > C1, (B1*λ_sq)/(λ_sq-C1), 0)
    term2 = np.where(λ_sq > C2, (B2*λ_sq)/(λ_sq-C2), 0)
    term3 = np.where(λ_sq > C3, (B3*λ_sq)/(λ_sq-C3), 0)
    
    n_sq = 1 + term1 + term2 + term3
    
    # 确保n_sq为非负数，避免无效的平方根计算
    n_sq = np.maximum(n_sq, 1e-6)
    return np.sqrt(n_sq)

def load_and_preprocess(file_path, min_height=0.6, min_distance=50, prominence=0.3):
    """读取附件数据并检测干涉峰（动态调整参数）"""
    try:
        # 1. 读取Excel数据
        df = pd.read_excel(file_path, header=None, names=["v", "R"])
        
        # 处理数据类型问题
        df["v"] = pd.to_numeric(df["v"], errors="coerce")
        df["R"] = pd.to_numeric(df["R"], errors="coerce")
        df = df.dropna(subset=["v", "R"])
        
        # 过滤不合理的波数值
        df = df[(df["v"] > 500) & (df["v"] < 10000)]
        df = df.sort_values("v").reset_index(drop=True)
        
        # 添加波长列 (μm)
        df["λ"] = 10**4 / df["v"]
        df = df[(df["λ"] > 1) & (df["λ"] < 20)]  # 1-20μm的合理范围
        
        if len(df) == 0:
            print("没有有效的数据点，请检查输入文件")
            return None, None, None, None, None, None
        
        # 2. 动态检测干涉峰
        for attempt in range(3):
            peaks_idx, _ = find_peaks(
                df["R"],
                height=min_height,
                distance=min_distance,
                prominence=prominence,
                width=20
            )
            
            if 5 <= len(peaks_idx) <= 30:
                break
                
            # 动态调整参数
            if len(peaks_idx) < 5:
                min_height *= 0.9
                min_distance *= 0.8
            else:
                min_height *= 1.1
                min_distance *= 1.2
        else:
            print("警告：无法找到合理数量的干涉峰，使用当前检测结果")
        
        peaks_v = df.iloc[peaks_idx]["v"].values
        peaks_R = df.iloc[peaks_idx]["R"].values
        peaks_λ = df.iloc[peaks_idx]["λ"].values
        delta_λ = np.diff(peaks_λ)
        
        return df, peaks_idx, peaks_v, peaks_R, peaks_λ, delta_λ
        
    except Exception as e:
        print(f"处理文件时出错: {e}")
        return None, None, None, None, None, None

def multi_beam_interference(v, h, r1, r2, n, theta0_rad):
    """多光束干涉模型(考虑多次反射)"""
    λ = 10**4 / v  # 波长(μm)
    sin_theta = np.sin(theta0_rad)
    cos_theta = np.where(n > sin_theta, np.sqrt(1 - (sin_theta/n)**2), 0)
    delta = 4 * math.pi * n * h * cos_theta / λ
    R = (r1**2 + r2**2 - 2*r1*r2*np.cos(delta)) / (1 + (r1*r2)**2 - 2*r1*r2*np.cos(delta))
    return R * 100  # 转换为百分比

def multiple_reflection_fit(peaks_λ, peaks_v, peaks_R, theta0=10):
    """多次反射干涉模型拟合函数"""
    theta0_rad = math.radians(theta0)
    sin_theta = np.sin(theta0_rad)
    
    def interference_model(v, h, r1, r2):
        λ = 10**4 / v
        n = refractive_index(λ)
        cos_theta = np.where(n > sin_theta, np.sqrt(1 - (sin_theta/n)**2), 0)
        delta = 4 * math.pi * n * h * cos_theta / λ
        R = (r1**2 + r2**2 - 2*r1*r2*np.cos(delta)) / (1 + (r1*r2)**2 - 2*r1*r2*np.cos(delta))
        return R * 100
    
    # 初始参数估计
    r1_guess = 0.2
    r2_guess = 0.3
    h_guess = 10.0
    
    try:
        popt, pcov = curve_fit(
            interference_model,
            peaks_v,
            peaks_R,
            p0=[h_guess, r1_guess, r2_guess],
            bounds=([1, 0, 0], [100, 1, 1])
        )
        h_fit, r1_fit, r2_fit = popt
        h_error = np.sqrt(pcov[0,0])
        
        # 计算拟合优度
        residuals = peaks_R - interference_model(peaks_v, h_fit, r1_fit, r2_fit)
        ss_res = np.sum(residuals**2)
        ss_tot = np.sum((peaks_R - np.mean(peaks_R))**2)
        r_squared = 1 - (ss_res / ss_tot) if ss_tot != 0 else 0
        
        return h_fit, r_squared, {
            'thickness': h_fit,
            'thickness_error': h_error,
            'confidence_interval': (h_fit - 1.96*h_error, h_fit + 1.96*h_error),
            'r1': r1_fit,
            'r2': r2_fit,
            'r_squared': r_squared,
            'peaks_used': len(peaks_v)
        }
    except Exception as e:
        print(f"拟合过程出错: {e}")
        return None, None, None

def analyze_attachment(file_path):
    """分析单个附件数据并计算厚度"""
    if "附件1" in file_path:
        theta0 = 10
        material = "碳化硅"
    elif "附件2" in file_path:
        theta0 = 15
        material = "碳化硅"
    else:
        theta0 = 10
        material = "未知材料"
    
    result = load_and_preprocess(file_path)
    if result[0] is None:
        return None
    df, peaks_idx, peaks_v, peaks_R, peaks_λ, delta_λ = result
    
    if len(peaks_v) < 3:
        print("检测到的峰数量不足，无法进行拟合")
        return None
    
    h_fit, r_squared, fit_results = multiple_reflection_fit(peaks_λ, peaks_v, peaks_R, theta0)
    if fit_results is None:
        return None
    
    # 打印结果
    print(f"\n{file_path} 分析结果(材料: {material}, 入射角 {theta0}°):")
    print(f"检测到的干涉峰数量: {len(peaks_v)}")
    print(f"计算厚度: {h_fit:.4f} μm")
    print(f"95%置信区间: ({fit_results['confidence_interval'][0]:.4f}, {fit_results['confidence_interval'][1]:.4f}) μm")
    print(f"拟合优度 R²: {r_squared:.4f}")
    
    return fit_results

if __name__ == "__main__":
    print("碳化硅外延层厚度分析:")
    try:
        print("\n分析附件1(10°入射角):")
        siC_10deg = analyze_attachment("附件1.xlsx")
        
        print("\n分析附件2(15°入射角):")
        siC_15deg = analyze_attachment("附件2.xlsx")
        
        if siC_10deg and siC_15deg:
            avg_thickness = (siC_10deg['thickness'] + siC_15deg['thickness']) / 2
            print(f"\n碳化硅外延层平均厚度: {avg_thickness:.4f} μm")
    except Exception as e:
        print(f"分析过程中发生错误: {str(e)}")